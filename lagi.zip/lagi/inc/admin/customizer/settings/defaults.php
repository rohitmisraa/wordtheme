<?php

/**
 * Default Customizer Options
 *
 * @package lagi
 */

/**
 *  Get default options
 */
if (!function_exists('lagi_get_default_theme_options')) {
	function lagi_get_default_theme_options()
	{
		$defaults = array();
		/**
		 *  General
		 */
		$defaults['smooth_scroll_enable']     = '1';
		$defaults['scroll_top_enable']        = '1';
		$defaults['content_protected_enable'] = '0';

		$defaults['logo_width']        = '';
		$defaults['logo_dark']         = LAGI_IMAGES . 'logo-dark.png';
		$defaults['logo_dark_retina']  = LAGI_IMAGES . 'logo-dark-retina.png';
		$defaults['logo_light']        = LAGI_IMAGES . 'logo-light.png';
		$defaults['logo_light_retina'] = LAGI_IMAGES . 'logo-light-retina.png';

		$defaults['type_loading_effect']      = 'none';
		$defaults['animation_loading_effect'] = 'css-1';
		$defaults['image_loading_effect']     = '';

		$defaults['user_account']    = '0';
		$defaults['url_phone']       = '68689888';
		$defaults['url_email']       = 'lagi@uxper.co';
		$defaults['url_facebook']    = '';
		$defaults['url_twitter']     = '';
		$defaults['url_instagram']   = '';
		$defaults['url_youtube']     = '';
		$defaults['url_google_plus'] = '';
		$defaults['url_skype']       = '';
		$defaults['url_linkedin']    = '';
		$defaults['url_pinterest']   = '';
		$defaults['url_slack']       = '';
		$defaults['url_rss']         = '';

		/**
		 *  Color
		 */
		$defaults['enable_color_mode']      =	'0';
		$defaults['default_color_mode']      =	'dark';

		$defaults['text_light_color']      =	'#555';
		$defaults['accent_light_color']    = 	'#F15EE5';
		$defaults['primary_light_color']   = 	'#111';
		$defaults['secondary_light_color'] = 	'#705cf633';
		$defaults['border_light_color']    =	'#eee';
		$defaults['bg_light_color']        = 	'#fff';
		$defaults['bg_sercondary_light_color']  = 	'#111';

		$defaults['text_dark_color']      =	'#ffffff99';
		$defaults['accent_dark_color']    = '#F15EE5';
		$defaults['primary_dark_color']   = '#fff';
		$defaults['secondary_dark_color'] = '#705cf633';
		$defaults['border_dark_color']    =	'#373737';
		$defaults['bg_dark_color']        = '#111';
		$defaults['bg_sercondary_dark_color']        = '#fff';

		/**
		 *  Typography
		 */
		$defaults['font-family']    = 'Inter';
		$defaults['font-size']      = '16px';
		$defaults['variant']        = 400;
		$defaults['line-height']    = 1.5;
		$defaults['letter-spacing'] = 'inherit';

		$defaults['heading-font-family']    = 'Outfit';
		$defaults['heading-line-height']    = 1.26;
		$defaults['heading-variant']        = 500;
		$defaults['heading-letter-spacing'] = 'inherit';

		/**
		 *  Button
		 */
		// General
		$defaults['button_font_family']            = 'Inter';
		$defaults['button_font_size']              = '16px';
		$defaults['button_variant']                = 600;
		$defaults['button_letter_spacing']         = '0';
		$defaults['button_text_transform']         = '';

		/**
		 *  Header
		 */
		$defaults['header_type']                 = '';
		$defaults['header_overlay']              = '0';
		$defaults['header_float']                = '0';
		$defaults['header_search_icon']          = '0';
		$defaults['header_button']               = '1';
		$defaults['header_link_button']          = '';
		$defaults['header_padding_top']          = '20';
		$defaults['header_padding_bottom']       = '20';

		/**
		 *  Page Title
		 */
		$defaults['page_title_type']                 = '';
		$defaults['page_title_align']                 = 'center';
		$defaults['page_title_padding_top']          = '80';
		$defaults['page_title_padding_bottom']       = '80';
		$defaults['enable_breadcrumb']       = '0';

		/**
		 *  Footer
		 */
		$defaults['footer_type']           = '';
		$defaults['footer_copyright_text'] = esc_attr__('© 2023 Uxper. All rights reserved', 'lagi');

		/**
		 *  Page 404
		 */
		$defaults['page404_type']   = '';
		$defaults['page404_image']  = LAGI_IMAGES . '/img-404.png';
		$defaults['page404_bg_image']  = LAGI_IMAGES . '/bg-404.gif';
		$defaults['page404_title']  = esc_html__('Oops...', 'lagi');
		$defaults['page404_text']   = esc_html__('The page you are looking for cannot be found', 'lagi');
		$defaults['page404_button'] = esc_html__('Go to homepage', 'lagi');

		/**
		 *  Blog
		 */
		$defaults['blog_archive_active_sidebar']           = 'blog_sidebar';
		$defaults['blog_archive_sidebar_position']         = 'none';
		$defaults['blog_archive_sidebar_width']            = 370;
		$defaults['blog_archive_page_title_layout']        = '';
		$defaults['blog_archive_display_categories']       = 'hide';
		$defaults['blog_archive_display_count_categories'] = 'hide';
		$defaults['blog_archive_display_action']       	   = 'hide';
		$defaults['blog_archive_display_count_post']       = 'show';
		$defaults['blog_archive_display_post_filter']      = 'show';
		$defaults['blog_archive_pagination_type']          = 'navigation';
		$defaults['blog_archive_pagination_position']      = 'center';
		$defaults['blog_desktop_column']                   = '3';
		$defaults['blog_tablet_column']                    = '2';
		$defaults['blog_mobile_column']                    = '1';
		$defaults['blog_content_post_gutter']              = '30';
		$defaults['blog_content_post_rowgap']              = '60';
		$defaults['blog_archive_post_layout']              = 'default';
		$defaults['blog_content_post_image_size']          = '740x740';
		$defaults['blog_content_post_card']                = 'hide';
		$defaults['blog_content_post_box']                 = 'hide';
		$defaults['blog_content_post_box_background']      = 'hide';
		$defaults['blog_content_post_categories']          = 'show';
		$defaults['blog_content_post_time']                = 'hide';
		$defaults['blog_content_post_comment']             = 'hide';
		$defaults['blog_content_post_excerpt']             = 'show';
		$defaults['blog_content_post_button']              = 'show';
		$defaults['blog_content_post_excerpt_number']      = 15;
		$defaults['blog_archive_header_type']              = '';
		$defaults['blog_archive_header_overlay']           = '';
		$defaults['blog_archive_header_float']             = '';
		$defaults['blog_archive_page_skin']              = '';

		$defaults['single_post_layout']                 = '01';
		$defaults['single_post_active_sidebar']         = 'blog_sidebar';
		$defaults['single_post_sidebar_position']       = 'none';
		$defaults['single_post_sidebar_width']          = 370;
		$defaults['single_post_title_fullscreen']       = 'hide';
		$defaults['single_post_page_title_layout']      = 'none';
		$defaults['single_post_boxed']     				= 'show';
		$defaults['single_post_display_categories']     = 'show';
		$defaults['single_post_display_date_time']      = 'show';
		$defaults['single_post_display_comment_count']  = 'hide';
		$defaults['single_post_display_title']          = 'show';
		$defaults['single_post_display_featured_image'] = 'show';
		$defaults['single_post_display_tags']           = 'show';
		$defaults['single_post_display_related']        = 'show';
		$defaults['single_post_display_comments']       = 'show';
		$defaults['single_post_header_type']            = '';
		$defaults['single_post_header_overlay']         = '';
		$defaults['single_post_header_float']           = '';
		$defaults['single_post_page_skin']            = '';


		/**
		 *  Portfolio
		 */
		$defaults['portfolio_archive_active_sidebar']           = 'portfolio_sidebar';
		$defaults['portfolio_archive_sidebar_position']         = 'none';
		$defaults['portfolio_archive_sidebar_width']            = 370;
		$defaults['portfolio_archive_page_title_layout']        = '';
		$defaults['portfolio_archive_display_taxonomy']       	= 'hide';
		$defaults['portfolio_archive_display_count_taxonomy'] 	= 'hide';
		$defaults['portfolio_archive_display_action']       	= 'hide';
		$defaults['portfolio_archive_display_count_post']       = 'show';
		$defaults['portfolio_archive_display_post_filter']      = 'show';
		$defaults['portfolio_archive_pagination_type']          = 'navigation';
		$defaults['portfolio_archive_pagination_position']      = 'center';
		$defaults['portfolio_desktop_column']                   = '3';
		$defaults['portfolio_tablet_column']                    = '2';
		$defaults['portfolio_mobile_column']                    = '1';
		$defaults['portfolio_content_post_gutter']              = '30';
		$defaults['portfolio_content_post_rowgap']              = '60';
		$defaults['portfolio_archive_post_layout']              = 'grid';
		$defaults['portfolio_content_post_image_size']          = '740x740';
		$defaults['portfolio_content_post_card']                = 'hide';
		$defaults['portfolio_content_minimal_style']            = 'hide';
		$defaults['portfolio_content_modern_style']      		= 'hide';
		$defaults['portfolio_content_post_taxonomy']          	= 'show';
		$defaults['portfolio_content_post_excerpt']             = 'show';
		$defaults['portfolio_content_post_button']              = 'show';
		$defaults['portfolio_content_post_excerpt_number']      = 15;
		$defaults['portfolio_archive_header_type']              = '';
		$defaults['portfolio_archive_header_overlay']           = '';
		$defaults['portfolio_archive_header_float']             = '';
		$defaults['portfolio_archive_page_skin']              = '';

		$defaults['single_portfolio_layout']                 = '01';
		$defaults['single_portfolio_active_sidebar']         = 'blog_sidebar';
		$defaults['single_portfolio_sidebar_position']       = 'right';
		$defaults['single_portfolio_sidebar_width']          = 370;
		$defaults['single_portfolio_title_fullscreen']       = 'hide';
		$defaults['single_portfolio_page_title_layout']      = '';
		$defaults['single_portfolio_boxed']     			 = 'show';
		$defaults['single_portfolio_display_taxonomy']     	 = 'show';
		$defaults['single_portfolio_display_date_time']      = 'show';
		$defaults['single_portfolio_display_comment_count']  = 'hide';
		$defaults['single_portfolio_display_title']          = 'show';
		$defaults['single_portfolio_display_meta']           = 'show';
		$defaults['single_portfolio_display_featured_image'] = 'show';
		$defaults['single_portfolio_display_tags']           = 'show';
		$defaults['single_portfolio_display_sharing']        = 'show';
		$defaults['single_portfolio_display_author']         = 'show';
		$defaults['single_portfolio_gallery']        	 	 = 'show';
		$defaults['single_portfolio_gallery_title']        	 = 'show';
		$defaults['single_portfolio_video_enable']        	 = 'show';
		$defaults['single_portfolio_video_title_enable']     = 'show';
		$defaults['single_portfolio_paginate']        		 = 'show';
		$defaults['single_portfolio_display_related']        = 'show';
		$defaults['single_portfolio_display_comments']       = 'show';
		$defaults['single_portfolio_header_type']            = '';
		$defaults['single_portfolio_header_overlay']         = '';
		$defaults['single_portfolio_header_float']           = '';
		$defaults['single_portfolio_page_skin']            = '';

		/**
		 *  Setup Page
		 */
		$defaults['setup_page_sign_in'] = '';
		$defaults['setup_page_terms'] = '';
		$defaults['setup_page_privacy_policy'] = '';
		$defaults['setup_page_forgot_password'] = '';
		$defaults['setup_page_reset_password'] = '';

		/**
		 *  Performance
		 */
		$defaults['performance_disable_emoji'] = '0';
		$defaults['performance_disable_embeds'] = '0';
		$defaults['performance_disable_style_css'] = '0';
		$defaults['performance_disable_blockcss'] = '0';
		$defaults['performance_jquery_migrate'] = '0';

		/**
		 *  Mouse
		 */
		$defaults['mouse_style'] = '0';
		$defaults['mouse_hidden_pointer'] = 'all';
		$defaults['mouse_width'] = '36';
		$defaults['mouse_height'] = '36';
		$defaults['mouse_border_radius'] = '100';
		$defaults['mouse_color'] = '#7D69FF';
		$defaults['mouse_border_color'] = '#7D69FF';
		$defaults['mouse_background_color'] = '';
		$defaults['mouse_transition_duration'] = '0.18';

		/**
		 *  WooCommerce
		 */
		if (class_exists('WooCommerce')) {
			$defaults['product_archive_active_sidebar']      = 'shop_sidebar';
			$defaults['product_archive_sidebar_position']    = 'none';
			$defaults['product_archive_sidebar_width']       = 370;
			$defaults['product_archive_page_title_layout']   = '';
			$defaults['product_archive_sorting']             = '1';
			$defaults['product_archive_number_item']         = 9;
			$defaults['product_archive_pagination_type']     = 'navigation';
			$defaults['product_archive_pagination_position'] = 'center';
			$defaults['product_archive_desktop_column']      = '3';
			$defaults['product_archive_tablet_column']       = '2';
			$defaults['product_archive_mobile_column']       = '1';
			$defaults['product_archive_layout']              = 'grid';
			$defaults['product_archive_image_size']          = '740x840';
			$defaults['product_archive_header_type']         = '';
			$defaults['product_archive_header_overlay']      = '';
			$defaults['product_archive_header_float']        = '';
			$defaults['product_archive_page_skin']         = '';

			$defaults['single_product_active_sidebar']     = 'shop_sidebar';
			$defaults['single_product_sidebar_position']   = 'right';
			$defaults['single_product_sidebar_width']      = 370;
			$defaults['single_product_page_title_layout']  = '';
			$defaults['single_product_breadcrumb_enable']  = '1';
			$defaults['single_product_sale_flash_enable']  = '1';
			$defaults['single_product_images_enable']      = '1';
			$defaults['single_product_title_enable']       = '1';
			$defaults['single_product_rating_enable']      = '1';
			$defaults['single_product_price_enable']       = '1';
			$defaults['single_product_excerpt_enable']     = '1';
			$defaults['single_product_add_to_cart_enable'] = '1';
			$defaults['single_product_meta_enable']        = '1';
			$defaults['single_product_tabs_enable']        = '1';
			$defaults['single_product_up_sells_enable']    = '1';
			$defaults['single_product_related_enable']     = '1';
			$defaults['single_product_header_type']        = '';
			$defaults['single_product_header_overlay']     = '';
			$defaults['single_product_header_float']       = '';
			$defaults['single_product_page_skin']        = '';
		}

		return $defaults;
	}
}

/**
 * Get Setting
 */
if (!function_exists('lagi_get_setting')) {
	function lagi_get_setting($key, $default = '')
	{
		$option = '';
		$option = Lagi_Kirki::get_option('theme', $key);

		return (!empty($option)) ? $option : $default;
	}
}
