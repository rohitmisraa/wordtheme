<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Customize')) {
	class Lagi_Customize
	{

		protected static $instance = null;
		private $wp_customize;

		static function instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize()
		{
			add_action('customize_preview_init', array($this, 'lagi_customizer_live_preview'));
			add_action('customize_controls_enqueue_scripts', array($this, 'lagi_customize_enqueue'), 10);
			add_action('customize_register', array($this, 'customize_register'));
			add_filter('kirki_fonts_standard_fonts', array($this, 'lagi_add_custom_font'));
			add_action('wp_enqueue_scripts', array($this, 'lagi_add_custom_font_css'));
			add_action('wp_ajax_customizer_import', array($this, 'ajax_customizer_import'));
			add_action('wp_ajax_customizer_reset', array($this, 'ajax_customizer_reset'));
			add_action('wp_ajax_lagi_header_builder', array($this, 'lagi_header_builder'));
			add_action('wp_ajax_lagi_header_delete_builder', array($this, 'lagi_header_delete_builder'));
		}

		function lagi_customizer_live_preview()
		{
			wp_enqueue_script('jquery-ui', get_template_directory_uri() . '/inc/admin/customizer/assets/libs/jquery-ui/jquery-ui.min.js', NULL, LAGI_THEME_VERSION, true);
			wp_enqueue_script('lagi-customize-preview', get_template_directory_uri() . '/inc/admin/customizer/assets/js/preview.js', array('jquery', 'customize-preview'), '', true);
			wp_localize_script(
				'lagi-customize-preview',
				'customize_preview',
				array(
					'ajax_url' => admin_url('admin-ajax.php'),
					'delete' => __('Do you want to delete current layout?', 'lagi'),
				)
			);

			wp_enqueue_style('jquery-ui', get_template_directory_uri() . '/inc/admin/customizer/assets/libs/jquery-ui/jquery-ui.min.css', array(), '', 'all');
			wp_enqueue_style('lagi-preview', get_template_directory_uri() . '/inc/admin/customizer/assets/css/preview.css', array());
		}

		function lagi_customize_enqueue()
		{
			wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/libs/font-awesome/css/fontawesome.min.css', array(), '5.1.0', 'all');
			wp_enqueue_style('lagi-customize', get_template_directory_uri() . '/inc/admin/customizer/assets/css/customize.css', array());
			wp_enqueue_script('lagi-customize-script', get_template_directory_uri() . '/inc/admin/customizer/assets/js/customize.js', array('jquery'), false, true);
			wp_localize_script('lagi-customize-script', 'customizeScript', array(
				'ajaxurl' => admin_url('admin-ajax.php', 'relative'),
				'reset'   => __('Reset', 'lagi'),
				'import'  => __('Do you want to import customizer options?', 'lagi'),
				'export'  => __('Do you want to export customizer options?', 'lagi'),
				'confirm' => __("Attention! This will remove all customizations ever made via customizer to this theme!\n\nThis action is irreversible!", 'lagi'),
				'nonce'   => array(
					'reset' => wp_create_nonce('customizer-reset'),
				)
			));
		}

		function lagi_add_custom_font($fonts)
		{
			$fonts['Cormorant Garamond'] = [
				'label'    => 'Cormorant Garamond',
				'variants' => [
					100,
					200,
					300,
					'regular',
					500,
					600,
					700,
					800,
					900,
				],
				'stack' => 'Cormorant Garamond',
			];

			return $fonts;
		}

		function lagi_add_custom_font_css()
		{
			$typo_fields = Lagi_Kirki::get_typography_fields_id();

			if (!is_array($typo_fields) || empty($typo_fields)) {
				return;
			}

			$fonts = [];

			foreach ($typo_fields as $field) {
				$value = Lagi_Helper::setting($field);

				if (is_array($value) && !empty($value['font-family']) && 'inherit' !== $value['font-family']) {
					$fonts[] = $value['font-family'];
				}
			}

			if (!empty($fonts)) {
				$fonts = array_unique($fonts);

				foreach ($fonts as $font) {
					if (strpos($font, 'Cormorant Garamond') !== false) {
						wp_enqueue_style('lagi-font-cormorant', LAGI_THEME_URI . '/assets/fonts/CormorantGaramond/stylesheet.css', null, null);
					} else {
						do_action('lagi_enqueue_custom_font', $font); // hook to custom do enqueue fonts
					}
				}
			}
		}

		public static function get_md_media_query()
		{
			return '@media (max-width: 1199px)';
		}

		public static function get_sm_media_query()
		{
			return '@media (max-width: 991px)';
		}

		public static function get_xs_media_query()
		{
			return '@media (max-width: 767px)';
		}

		/**
		 * Get Page Title
		 */
		public static function get_list_page_titles($default_option = true)
		{
			$page_title = Lagi_Global::get_list_page_titles(false);
			if ($default_option === true) {
				$page_title = Lagi_Global::get_list_page_titles(true);
			}

			return $page_title;
		}


		/**
		 * Get list header
		 */
		public static function lagi_get_headers($default_option = true)
		{
			$headers = Lagi_Global::get_list_headers(false);
			if ($default_option === true) {
				$headers = Lagi_Global::get_list_headers(true);
			}

			return $headers;
		}

		/**
		 * Get list header
		 */
		public static function lagi_get_footers($default_option = true)
		{
			$footers = Lagi_Global::get_list_footers(false);
			if ($default_option === true) {
				$footers = Lagi_Global::get_list_footers(true);
			}

			return $footers;
		}

		/**
		 * Get list footer
		 */
		public static function lagi_get_footers_elementor()
		{
			$footers = get_posts(array(
				'posts_per_page' => -1,
				'post_type'      => 'elementor_library',
				'tax_query'      => array(
					array(
						'taxonomy' => 'elementor_library_type',
						'field'    => 'slug',
						'terms'    => 'footer',
					)
				),
			));

			$arr_footer = array();
			foreach ($footers as $footer) {
				$arr_footer[$footer->ID] = ucwords($footer->post_name);
			}

			return $arr_footer;
		}

		function customize_register($wp_customize)
		{
			$this->wp_customize = $wp_customize;
			$this->lagi_customizer_create_path();
		}

		/**
		 * Get Select page
		 */
		public static function lagi_get_select_page()
		{
			$of_categories     = array();
			$of_categories_obj = get_categories('hide_empty=0');
			foreach ($of_categories_obj as $of_cat) {
				$of_categories[$of_cat->cat_ID] = $of_cat->cat_name;
			}

			// Access the WordPress Pages via an Array.
			$of_pages      = array();
			$of_pages_obj  = get_pages('sort_column=post_parent,menu_order');
			$of_pages['0'] = esc_html__('Select a page', 'lagi');
			foreach ($of_pages_obj as $of_page) {
				$of_pages[$of_page->ID] = $of_page->post_title;
			}

			return $of_pages;
		}

		/**
		 * get elementor library
		 */
		public static function lagi_get_elementor_library()
		{
			$elementors = get_posts(array(
				'post_type'      => 'elementor_library',
				'posts_per_page' => -1,
			));

			$arr_elementors = array('' => esc_html('Default', 'lagi'));

			foreach ($elementors as $elementor) {
				$arr_elementors[$elementor->ID] = ucwords($elementor->post_title);
			}

			return $arr_elementors;
		}

		function ajax_customizer_import()
		{
			$options = unserialize($this->lagi_get_contents($_FILES['file']['tmp_name']));
			if (is_array($options)) {
				foreach ($options as $key => $val) {
					set_theme_mod($key, $val);
				}
			}
			echo json_encode(array('options' => $options, 'status' => 1, 'message' => __('Import is successful!', 'lagi')));
			wp_die();
		}

		function ajax_customizer_reset()
		{
			if (!$this->wp_customize->is_preview()) {
				wp_send_json_error('not_preview');
			}

			if (!check_ajax_referer('customizer-reset', 'nonce', false)) {
				wp_send_json_error('invalid_nonce');
			}

			$settings = $this->wp_customize->settings();

			// remove theme_mod settings registered in customizer
			foreach ($settings as $setting) {
				if ('theme_mod' == $setting->type) {
					remove_theme_mod($setting->id);
				}
			}

			wp_send_json_success();
		}

		function lagi_get_contents($path)
		{
			require_once(ABSPATH . 'wp-admin/includes/file.php');
			WP_Filesystem();
			global $wp_filesystem;

			$get_content = '';
			if (function_exists('realpath')) {
				$filepath = realpath($path);
			}
			if (!$filepath || !@is_file($filepath)) {
				return '';
			}

			return $wp_filesystem->get_contents($filepath);
		}

		function lagi_header_builder()
		{
			require_once(ABSPATH . 'wp-admin/includes/file.php');
			WP_Filesystem();
			global $wp_filesystem;

			$css        = stripslashes($_POST['css']);
			$header     = Lagi_Helper::lagi_clean(wp_unslash($_POST['header']));
			$header_obj = $_POST['header_obj'];

			update_option($header, $header_obj['header']);

			$this->lagi_customizer_create_file($header, 'css', $css);

			return true;

			wp_die();
		}

		function lagi_header_delete_builder()
		{

			$header = Lagi_Helper::lagi_clean(wp_unslash($_POST['header']));

			delete_option($header);

			return true;

			wp_die();
		}


		/**
		 * Create Path
		 */
		function lagi_customizer_create_path()
		{
			$upload_dir = wp_upload_dir();
			$logger_dir = $upload_dir['basedir'] . '/lagi/header';

			if (!file_exists($logger_dir)) {
				wp_mkdir_p($logger_dir);
			}
		}

		function lagi_customizer_create_file($name, $path, $css)
		{
			require_once(ABSPATH . 'wp-admin/includes/file.php');
			WP_Filesystem();
			global $wp_filesystem;

			$upload_dir = wp_upload_dir();
			$logger_dir = $upload_dir['basedir'] . '/lagi/header';

			$name = $name . '.' . $path;
			$wp_filesystem->put_contents(trailingslashit($logger_dir) . $name, $css);
		}
	}

	Lagi_Customize::instance()->initialize();
}
