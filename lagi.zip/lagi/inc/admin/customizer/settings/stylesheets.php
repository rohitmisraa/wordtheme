<?php

// Add style to style.css mytheme
function lagi_add_customizer_styles()
{
    $custom_css = lagi_get_customizer_css();
    wp_add_inline_style('lagi-style', $custom_css);
}
add_action('wp_enqueue_scripts', 'lagi_add_customizer_styles', 99);

function lagi_get_customizer_css()
{
    $css = $page_title_tmp = $overlay_tmp = '';

    //Page Title
    $type = Lagi_Global::instance()->get_page_title_type();
    $bg_type = Lagi_Helper::setting("page_title_{$type}_background_type");

    $text_light_color            = Lagi_Helper::setting('text_light_color');
    $accent_light_color        = Lagi_Helper::setting('accent_light_color');
    $primary_light_color        = Lagi_Helper::setting('primary_light_color');
    $secondary_light_color        = Lagi_Helper::setting('secondary_light_color');
    $border_light_color        = Lagi_Helper::setting('border_light_color');
    $bg_light_color            = Lagi_Helper::setting('bg_light_color');
    $bg_sercondary_light_color = Lagi_Helper::setting('bg_sercondary_light_color');

    $text_dark_color            = Lagi_Helper::setting('text_dark_color');
    $accent_dark_color               = Lagi_Helper::setting('accent_dark_color');
    $primary_dark_color        = Lagi_Helper::setting('primary_dark_color');
    $secondary_dark_color        = Lagi_Helper::setting('secondary_dark_color');
    $border_dark_color         = Lagi_Helper::setting('border_dark_color');
    $bg_dark_color             = Lagi_Helper::setting('bg_dark_color');
    $bg_sercondary_dark_color             = Lagi_Helper::setting('bg_sercondary_dark_color');

    ob_start();

    if ('gradient' === $bg_type) {
        $gradient_color = Lagi_Helper::setting("page_title_{$type}_background_gradient");
        $color1         = $gradient_color['color_1'];
        $color2         = $gradient_color['color_2'];

        $css .= "
            .page-title-bg
            {
                background-color: $color1;
                background-image: linear-gradient(-180deg, {$color1} 0%, {$color2} 100%);
            }
        ";
    }

    $bg_color   = Lagi_Helper::get_post_meta('page_page_title_background_color', '');
    $bg_image   = Lagi_Helper::get_post_meta('page_page_title_background', '');
    $bg_overlay = Lagi_Helper::get_post_meta('page_page_title_background_overlay', '');

    if ($bg_color !== '') {
        $page_title_tmp .= "background-color: {$bg_color}!important;";
    }

    if ('' !== $bg_image) {
        $page_title_tmp .= "background-image: url({$bg_image})!important;";
    }

    if ('' !== $bg_overlay) {
        $overlay_tmp .= "background-color: {$bg_overlay}!important;";
    }

    if ('' !== $page_title_tmp) {
        $css .= ".page-title-bg{ {$page_title_tmp} }";
    }

    if ('' !== $overlay_tmp) {
        $css .= ".page-title-bg:before{ {$overlay_tmp} }";
    }

    $bottom_spacing = Lagi_Helper::get_post_meta('page_page_title_bottom_spacing', '');
    if ('' !== $bottom_spacing) {
        $css .= ".page-title{ margin-bottom: {$bottom_spacing}; }";
    }

    //Color
?>
    .lagi-light-scheme {
    --lagi-color-text: <?php echo $text_light_color; ?>;
    --lagi-color-accent: <?php echo $accent_light_color; ?>;
    --lagi-color-primary: <?php echo $primary_light_color; ?>;
    --lagi-color-secondary: <?php echo $secondary_light_color; ?>;
    --lagi-color-border: <?php echo $border_light_color; ?>;
    --lagi-color-bg: <?php echo $bg_light_color; ?>;
    --lagi-color-bg-sercondary: <?php echo $bg_sercondary_light_color; ?>;
    --lagi-bg-grey: #f9f9f9;
    --lagi-border-color: #eee;
    }

    .lagi-dark-scheme{
    --lagi-color-text: <?php echo $text_dark_color; ?>;
    --lagi-color-accent: <?php echo $accent_dark_color; ?>;
    --lagi-color-primary: <?php echo $primary_dark_color; ?>;
    --lagi-color-secondary: <?php echo $secondary_dark_color; ?>;
    --lagi-color-border: <?php echo $border_dark_color; ?>;
    --lagi-color-bg: <?php echo $bg_dark_color; ?>;
    --lagi-color-bg-sercondary: <?php echo $bg_sercondary_dark_color; ?>;

    --e-global-color-primary: <?php echo $primary_dark_color; ?> !important;
    --e-global-color-secondary: <?php echo $secondary_dark_color; ?> !important;
    --e-global-color-text: <?php echo $text_dark_color; ?> !important;
    --e-global-color-accent: <?php echo $accent_dark_color; ?> !important;
    --e-global-color-4e4430e: <?php echo $border_dark_color; ?> !important;
    --e-global-color-1ac9c98: #111 !important;
    --lagi-bg-grey: #252428;
    --lagi-border-color: #333;
    }

<?php



    $css = ob_get_clean();

    return $css;
}
