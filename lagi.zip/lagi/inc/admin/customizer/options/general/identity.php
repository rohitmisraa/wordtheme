<?php

$section  = 'site_identity';
$priority = 1;

// Site Identity
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Site Identity', 'lagi'),
	'panel'    => $panel,
	'priority' => $priority++,
));
