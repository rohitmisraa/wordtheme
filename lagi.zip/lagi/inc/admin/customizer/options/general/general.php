<?php

$section  = 'general';
$prefix   = 'general_';
$priority = 1;

// Logo
Lagi_Kirki::add_section($section, array(
    'title'    => esc_html__('General', 'lagi'),
    'panel'    => $panel,
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => $prefix . 'notice',
    'label'    => esc_html__('General', 'lagi'),
    'section'  => $section,
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => 'smooth_scroll_enable',
    'label'     => esc_html__('Enable Smooth Scroll', 'lagi'),
    'section'   => $section,
    'default'   => $default['smooth_scroll_enable'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => 'scroll_top_enable',
    'label'     => esc_html__('Enable Go To Top', 'lagi'),
    'section'   => $section,
    'default'   => $default['scroll_top_enable'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => 'content_protected_enable',
    'label'     => esc_html__('Enable Content Protected', 'lagi'),
    'section'   => $section,
    'default'   => $default['content_protected_enable'],
]);
