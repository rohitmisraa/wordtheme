<?php

$section  = 'logo';
$prefix   = 'logo_';
$priority = 1;

// Logo
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Logo', 'lagi'),
	'panel'    => $panel,
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => $prefix . 'width',
	'label'     => esc_html__('Logo Width', 'lagi'),
	'section'   => $section,
	'priority' => $priority++,
	'default'   => $default[$prefix . 'width'],
	'choices'   => [
		'min'  => 0,
		'max'  => 500,
		'step' => 1,
	],
	'output'    => array(
		array(
			'element'  => '.site-logo img',
			'property' => 'width',
			'units'    => 'px',
		),
	),
]);


Lagi_Kirki::add_field('theme', [
	'type'     => 'image',
	'settings' => $prefix . 'dark',
	'label'    => esc_html__('Logo Dark', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'dark'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'image',
	'settings' => $prefix . 'dark_retina',
	'label'    => esc_html__('Logo Dark Retina', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'dark_retina'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'image',
	'settings' => $prefix . 'light',
	'label'    => esc_html__('Logo Light', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'light'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'image',
	'settings' => $prefix . 'light_retina',
	'label'    => esc_html__('Logo Light Retina', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'light_retina'],
]);
