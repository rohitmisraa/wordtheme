<?php

$section  = 'pre_loading';
$prefix   = 'pre_loading_';
$priority = 1;

// Page Loading Effect
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Pre Loading', 'lagi'),
	'panel'    => $panel,
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio',
	'settings' => 'type_loading_effect',
	'label'    => esc_html__('Type Loading Effect', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['type_loading_effect'],
	'choices'  => [
		'none'          => esc_attr__('None', 'lagi'),
		'css_animation' => esc_attr__('CSS Animation', 'lagi'),
		'image'         => esc_attr__('Image', 'lagi'),
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'color-alpha',
	'settings'  => 'page_loading_effect_bg_color',
	'label'     => esc_html__('Background Color', 'lagi'),
	'section'   => $section,
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => '#fff',
	'output'    => array(
		array(
			'element'  => '.page-loading-effect',
			'property' => 'background-color',
		),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'color-alpha',
	'settings'  => 'page_loading_effect_shape_color',
	'label'     => esc_html__('Shape Color', 'lagi'),
	'section'   => $section,
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default['accent_light_color'],
	'output'    => array(
		array(
			'element'  => '.lagi-ldef-circle > span,.lagi-ldef-facebook span,.lagi-ldef-heart span,.lagi-ldef-heart span:after,
			.lagi-ldef-heart span:before,.lagi-ldef-roller span:after,.lagi-ldef-default span,.lagi-ldef-ellipsis span,
			.lagi-ldef-grid span,.lagi-ldef-spinner span:after',
			'property' => 'background-color',
		),
		array(
			'element'  => '.lagi-ldef-ripple span',
			'property' => 'border-color',
		),
		array(
			'element'  => '.lagi-ldef-dual-ring:after,.lagi-ldef-ring span,.lagi-ldef-hourglass:after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.lagi-ldef-dual-ring:after,.lagi-ldef-hourglass:after',
			'property' => 'border-bottom-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'type_loading_effect',
			'operator' => '=',
			'value'    => 'css_animation',
		),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'animation_loading_effect',
	'label'    => esc_html__('Animation Type', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['animation_loading_effect'],
	'choices'  => [
		'css-1'  => '<span class="lagi-ldef-circle lagi-ldef-loading"><span></span></span>',
		'css-2'  => '<span class="lagi-ldef-dual-ring lagi-ldef-loading"></span>',
		'css-3'  => '<span class="lagi-ldef-facebook lagi-ldef-loading"><span></span><span></span><span></span></span>',
		'css-4'  => '<span class="lagi-ldef-heart lagi-ldef-loading"><span></span></span>',
		'css-5'  => '<span class="lagi-ldef-ring lagi-ldef-loading"><span></span><span></span><span></span><span></span></span>',
		'css-6'  => '<span class="lagi-ldef-roller lagi-ldef-loading"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>',
		'css-7'  => '<span class="lagi-ldef-default lagi-ldef-loading"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>',
		'css-8'  => '<span class="lagi-ldef-ellipsis lagi-ldef-loading"><span></span><span></span><span></span><span></span></span>',
		'css-9'  => '<span class="lagi-ldef-grid lagi-ldef-loading"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>',
		'css-10' => '<span class="lagi-ldef-hourglass lagi-ldef-loading"></span>',
		'css-11' => '<span class="lagi-ldef-ripple lagi-ldef-loading"><span></span><span></span></span>',
		'css-12' => '<span class="lagi-ldef-spinner lagi-ldef-loading"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span>',
	],
	'active_callback' => array(
		array(
			'setting'  => 'type_loading_effect',
			'operator' => '=',
			'value'    => 'css_animation',
		),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'image',
	'settings' => 'image_loading_effect',
	'label'    => esc_html__('Image', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['image_loading_effect'],
	'active_callback' => array(
		array(
			'setting'  => 'type_loading_effect',
			'operator' => '=',
			'value'    => 'image',
		),
	),
]);
