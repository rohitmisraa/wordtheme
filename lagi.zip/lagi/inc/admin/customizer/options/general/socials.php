<?php

$section  = 'socials';
$prefix   = 'socials_';
$priority = 1;

// Socials Profile
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Socials', 'lagi'),
	'panel'    => $panel,
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', array(
	'type'     => 'radio-buttonset',
	'settings' => 'user_account',
	'label'    => esc_html__('User Account', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['user_account'],
	'choices'  => array(
		'0' => esc_attr__('No', 'lagi'),
		'1' => esc_attr__('Yes', 'lagi'),
	),
));

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_phone',
	'label'    => esc_html__('Phone', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_phone'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_email',
	'label'    => esc_html__('Email', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_email'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_facebook',
	'label'    => esc_html__('Facebook', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_facebook'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_twitter',
	'label'    => esc_html__('Twitter', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_twitter'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_instagram',
	'label'    => esc_html__('Instagram', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_instagram'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_youtube',
	'label'    => esc_html__('Youtube', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_youtube'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_google_plus',
	'label'    => esc_html__('Google Plus', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_google_plus'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_skype',
	'label'    => esc_html__('Skype', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_skype'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_linkedin',
	'label'    => esc_html__('Linkedin', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_linkedin'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_pinterest',
	'label'    => esc_html__('Pinterest', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_pinterest'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_slack',
	'label'    => esc_html__('Slack', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_slack'],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => 'url_rss',
	'label'    => esc_html__('RSS', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default['url_rss'],
]);
