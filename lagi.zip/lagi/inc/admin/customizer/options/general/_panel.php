<?php

$panel    = 'general';
$priority = 1;

// General
Lagi_Kirki::add_panel($panel, array(
	'title'    => esc_html__('General Option', 'lagi'),
	'priority' => $priority++,
));
