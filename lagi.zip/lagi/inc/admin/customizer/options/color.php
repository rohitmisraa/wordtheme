<?php

$priority = 1;
$section  = 'color';

// Color Light
Lagi_Kirki::add_section($section, array(
    'title'    => esc_html__('Color Option', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'enable_color_mode',
    'label'    => esc_html__('Color Mode Switcher', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
    'default'  => $default['enable_color_mode'],
    'choices'  => array(
        '1' => esc_attr__('Enable', 'lagi'),
        '0' => esc_attr__('Disable', 'lagi'),
    ),
    'active_callback' => function () {
        return false;
    },
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'default_color_mode',
    'label'    => esc_html__('Default Color Mode', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
    'default'  => $default['default_color_mode'],
    'choices'  => array(
        'dark' => esc_attr__('Dark', 'lagi'),
        'light' => esc_attr__('Light', 'lagi'),
    ),
    'active_callback' => function () {
        return false;
    },
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => 'notice_light_color',
    'label'    => esc_html__('Color Light', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'text_light_color',
    'label'     => esc_html__('Text Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['text_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'accent_light_color',
    'label'     => esc_html__('Accent Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['accent_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'primary_light_color',
    'label'     => esc_html__('Primary Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['primary_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color',
    'settings'  => 'secondary_light_color',
    'label'     => esc_html__('Secondary Color', 'lagi'),
    'section'   => $section,
    'transport' => 'postMessage',
    'default'   => $default['secondary_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'border_light_color',
    'label'     => esc_html__('Border Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['border_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'bg_light_color',
    'label'     => esc_html__('Background Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['bg_light_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'bg_sercondary_light_color',
    'label'     => esc_html__('Background Sercondary Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['bg_sercondary_light_color'],
]);

// Color Dark
Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => 'notice_dark_color',
    'label'    => esc_html__('Color Dark', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'text_dark_color',
    'label'     => esc_html__('Text Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['text_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'accent_dark_color',
    'label'     => esc_html__('Accent Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['accent_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'primary_dark_color',
    'label'     => esc_html__('Primary Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['primary_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color',
    'settings'  => 'secondary_dark_color',
    'label'     => esc_html__('Secondary Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'postMessage',
    'default'   => $default['secondary_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'border_dark_color',
    'label'     => esc_html__('Border Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['border_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'bg_dark_color',
    'label'     => esc_html__('Background Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['bg_dark_color'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'color-alpha',
    'settings'  => 'bg_sercondary_dark_color',
    'label'     => esc_html__('Background Sercondary Color', 'lagi'),
    'section'   => $section,
    'priority'  => $priority++,
    'transport' => 'auto',
    'default'   => $default['bg_sercondary_dark_color'],
]);
