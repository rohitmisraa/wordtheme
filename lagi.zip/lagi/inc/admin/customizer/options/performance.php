<?php
$priority = 1;
$section = 'performance';
$prefix   = 'performance_';

// Header
Lagi_Kirki::add_section($section, array(
    'title'    => esc_html__('Performance', 'lagi'),
    'description' => esc_html__('Use with caution! Disable if you have plugin compatibility problems.', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => $prefix . 'performance',
    'label'    => esc_html__('Performance', 'lagi'),
    'section'  => $section,
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => $prefix . 'disable_emoji',
    'label'     => esc_html__('Disable Emoji', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'disable_emoji'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => $prefix . 'disable_embeds',
    'label'     => esc_html__('Disable Embeds', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'disable_embeds'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => $prefix . 'disable_style_css',
    'label'     => esc_html__('Disable Style Css', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'disable_style_css'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => $prefix . 'disable_blockcss',
    'label'     => esc_html__('Disable Block Css', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'disable_blockcss'],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => $prefix . 'jquery_migrate',
    'label'     => esc_html__('Disable Jquery Migrate', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'jquery_migrate'],
]);
