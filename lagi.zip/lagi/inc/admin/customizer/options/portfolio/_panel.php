<?php

$panel    = 'portfolio';
$priority = 1;

// Portfolio Panel
Lagi_Kirki::add_panel($panel, array(
	'title'    => esc_html__('Portfolio Option', 'lagi'),
	'priority' => $priority++,
));
