<?php

// Single portfolio
Lagi_Kirki::add_section('single_portfolio', array(
    'title'    => esc_html__('Single Portfolio', 'lagi'),
    'panel'    => $panel,
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => 'single_portfolio_customize',
    'label'    => esc_html__('Single Portfolio', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => 'single_portfolio_layout',
    'label'    => esc_html__('Layout Style', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_layout'],
    'choices'  => [
        '01' => esc_attr__('01', 'lagi'),
        '02' => esc_attr__('02', 'lagi'),
        '03' => esc_attr__('03', 'lagi'),
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => 'single_portfolio_page_title_layout',
    'label'    => esc_html__('Page Title', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_page_title_layout'],
    'choices'  => Lagi_Global::get_list_page_titles(),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_display_taxonomy',
    'label'    => esc_html__('Display Taxonomy', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_display_taxonomy'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_display_title',
    'label'    => esc_html__('Display Portfolio Title', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_display_title'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_display_meta',
    'label'    => esc_html__('Display Portfolio Meta', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_display_meta'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_gallery',
    'label'    => esc_html__('Display Gallery', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_gallery'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_gallery_title',
    'label'    => esc_html__('Display Gallery Title', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_gallery_title'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
    'active_callback' => [
        [
            'setting'  => 'single_portfolio_gallery',
            'operator' => '==',
            'value'    => 'show',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_video_enable',
    'label'    => esc_html__('Display Video', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_video_enable'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
    'active_callback' => [
        [
            'setting'  => 'single_portfolio_layout',
            'operator' => '!=',
            'value'    => '03',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_video_title_enable',
    'label'    => esc_html__('Display Video Title', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_video_title_enable'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
    'active_callback' => [
        [
            'setting'  => 'single_portfolio_layout',
            'operator' => '!=',
            'value'    => '03',
        ],
        [
            'setting'  => 'single_portfolio_video_enable',
            'operator' => '==',
            'value'    => 'show',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_paginate',
    'label'    => esc_html__('Display Paginate', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_paginate'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_display_related',
    'label'    => esc_html__('Display Related Portfolio', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_display_related'],
    'choices'  => array(
        'hide' => esc_attr__('Hide', 'lagi'),
        'show' => esc_attr__('Show', 'lagi'),
    ),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => 'single_portfolio_header',
    'label'    => esc_attr__('Header', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', array(
    'type'        => 'select',
    'settings'    => 'single_portfolio_header_type',
    'label'       => esc_html__('Header Style', 'lagi'),
    'description' => esc_html__('Select header style that displays on portfolio archive pages.', 'lagi'),
    'section'     => 'single_portfolio',
    'priority'    => $priority++,
    'default'     => $default['single_portfolio_header_type'],
    'choices'     => Lagi_Global::get_list_page_titles(),
));

Lagi_Kirki::add_field('theme', array(
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_header_overlay',
    'label'    => esc_html__('Header Overlay', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_header_overlay'],
    'choices'  => array(
        ''  => esc_html__('Default', 'lagi'),
        '0' => esc_html__('No', 'lagi'),
        '1' => esc_html__('Yes', 'lagi'),
    ),
));

Lagi_Kirki::add_field('theme', array(
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_header_float',
    'label'    => esc_html__('Header Float', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_header_float'],
    'choices'  => array(
        ''  => esc_attr__('Default', 'lagi'),
        '0' => esc_attr__('No', 'lagi'),
        '1' => esc_attr__('Yes', 'lagi'),
    ),
));

Lagi_Kirki::add_field('theme', array(
    'type'     => 'radio-buttonset',
    'settings' => 'single_portfolio_page_skin',
    'label'    => esc_html__('Page Skin', 'lagi'),
    'section'  => 'single_portfolio',
    'priority' => $priority++,
    'default'  => $default['single_portfolio_page_skin'],
    'choices'  => array(
        ''      => esc_html__('Default', 'lagi'),
        'dark'  => esc_html__('Dark', 'lagi'),
        'light' => esc_html__('Light', 'lagi'),
    ),
));
