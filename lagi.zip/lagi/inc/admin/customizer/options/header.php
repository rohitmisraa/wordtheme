<?php
$priority = 1;
$section = 'header';
$prefix   = 'header_';

// Header
Lagi_Kirki::add_section($section, array(
    'title'    => esc_html__('Header Option', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => $prefix . 'customize',
    'label'    => esc_html__('Header Customize', 'lagi'),
    'section'  => $section,
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'type',
    'label'    => esc_html__('Header Type', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'type'],
    'choices'  => Lagi_Customize::lagi_get_headers(),
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings'  => $prefix . 'overlay',
    'label'     => esc_html__('Enable Sticky', 'lagi'),
    'section'   => $section,
    'transport' => 'postMessage',
    'default'   => $default[$prefix . 'overlay'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings'  => $prefix . 'float',
    'label'     => esc_html__('Enable Float', 'lagi'),
    'section'   => $section,
    'transport' => 'postMessage',
    'default'   => $default[$prefix . 'float'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings'  => $prefix . 'search_icon',
    'label'     => esc_html__('Show Search Icon', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'search_icon'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings'  => $prefix . 'button',
    'label'     => esc_html__('Show Button "Let’s Talk"', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'button'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'link_button',
    'label'    => esc_html__('Link Button', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'link_button'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
    'active_callback' => [
        [
            'setting'  => $prefix . 'button',
            'operator' => '==',
            'value'    => true,
        ],
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ],
    ],
]);


Lagi_Kirki::add_field('theme', [
    'type'      => 'slider',
    'settings'  => $prefix . 'padding_top',
    'label'     => esc_html__('Padding Top', 'lagi'),
    'section'   => $section,
    'transport' => 'auto',
    'default'   => $default[$prefix . 'padding_top'],
    'choices'   => [
        'min'  => 0,
        'max'  => 200,
        'step' => 1,
    ],
    'output'    => array(
        array(
            'element'  => 'header.site-header',
            'property' => 'padding-top',
            'units'    => 'px',
        ),
    ),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'slider',
    'settings'  => $prefix . 'padding_bottom',
    'label'     => esc_html__('Padding Bottom', 'lagi'),
    'section'   => $section,
    'transport' => 'postMessage',
    'default'   => $default[$prefix . 'padding_bottom'],
    'choices'   => [
        'min'  => 0,
        'max'  => 200,
        'step' => 1,
    ],
    'output'    => array(
        array(
            'element'  => 'header.site-header',
            'property' => 'padding-bottom',
            'units'    => 'px',
        ),
    ),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);
