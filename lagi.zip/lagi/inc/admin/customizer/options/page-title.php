<?php
$priority = 1;
$section = 'page_title';
$prefix  = 'page_title_';

Lagi_Kirki::add_section($section, array(
    'title' => esc_attr__('Page Title', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => $prefix . 'notice',
    'label'    => esc_html__('Page Title Option', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'type',
    'label'    => esc_html__('Page Title Type', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'type'],
    'choices'  => Lagi_Customize::get_list_page_titles(),
]);

Lagi_Kirki::add_field('theme', [
    'type'      => 'radio-buttonset',
    'settings'  => $prefix . 'align',
    'label'     => esc_html__('Align', 'lagi'),
    'section'   => $section,
    'default'   => $default[$prefix . 'align'],
    'choices'   => array(
        'left'   => esc_attr__('Left', 'lagi'),
        'center' => esc_attr__('Center', 'lagi'),
        'right'  => esc_attr__('Right', 'lagi'),
    ),
    'output'    => array(
        array(
            'element'  => '.page-title .page-title-inner',
            'property' => 'text-align',
        ),
    ),
]);

Lagi_Kirki::add_field('theme', array(
    'type'      => 'slider',
    'settings'  => $prefix . 'padding_top',
    'label'     => esc_html__('Padding Top', 'lagi'),
    'section'   => $section,
    'transport' => 'auto',
    'default'   => $default[$prefix . 'padding_top'],
    'choices'   => array(
        'min'  => 50,
        'max'  => 500,
        'step' => 1,
    ),
    'output'    => array(
        array(
            'element'  => '.page-title .page-title-inner',
            'property' => 'padding-top',
            'units'    => 'px',
        ),
    ),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'      => 'slider',
    'settings'  => $prefix . 'padding_bottom',
    'label'     => esc_html__('Padding Bottom', 'lagi'),
    'section'   => $section,
    'transport' => 'auto',
    'default'   => $default[$prefix . 'padding_bottom'],
    'choices'   => array(
        'min'  => 50,
        'max'  => 500,
        'step' => 1,
    ),
    'output'    => array(
        array(
            'element'  => '.page-title .page-title-inner',
            'property' => 'padding-bottom',
            'units'    => 'px',
        ),
    ),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', [
    'type'      => 'toggle',
    'settings' => 'enable_breadcrumb',
    'label'     => esc_html__('Enable Breadcrumb', 'lagi'),
    'section'   => $section,
    'default'   => $default['enable_breadcrumb'],
]);

Lagi_Kirki::add_field('theme', array(
    'type'     => 'notice',
    'settings' => $prefix . 'typography',
    'label'    => esc_attr__('Typography', 'lagi'),
    'section'  => $section,
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'kirki_typography',
    'settings'    => $prefix . 'heading_typography',
    'label'       => esc_html__('Font Family', 'lagi'),
    'description' => esc_html__('Controls the font family for the page title heading.', 'lagi'),
    'section'     => $section,
    'transport'   => 'auto',
    'default'     => array(
        'font-family'    => '',
        'variant'        => '700',
        'font-size'      => '64px',
        'line-height'    => '1.31',
        'letter-spacing' => '',
        'text-transform' => '',
    ),
    'output'      => array(
        array(
            'element' => '.page-title .heading',
        ),
    ),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => 'page_title_general_heading',
    'label'    => esc_attr__('Heading', 'lagi'),
    'section'  => $section,
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
]);

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_search_title',
    'label'       => esc_attr__('Search Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on search results page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Search results for: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_home_title',
    'label'       => esc_attr__('Home Heading', 'lagi'),
    'description' => esc_attr__('Enter text that displays on front latest posts page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Blog', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_category_title',
    'label'       => esc_attr__('Archive Category Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive category page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Category: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_tag_title',
    'label'       => esc_attr__('Archive Tag Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive tag page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Tag: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_author_title',
    'label'       => esc_attr__('Archive Author Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive author page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Author: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_year_title',
    'label'       => esc_attr__('Archive Year Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive year page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Year: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_month_title',
    'label'       => esc_attr__('Archive Month Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive month page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Month: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_day_title',
    'label'       => esc_attr__('Archive Day Heading', 'lagi'),
    'description' => esc_attr__('Enter text prefix that displays on archive day page.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Day: ', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_single_blog_title',
    'label'       => esc_attr__('Single Blog Heading', 'lagi'),
    'description' => esc_attr__('Enter text that displays on single blog posts. Leave blank to use post title.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Blog', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_archive_portfolio_title',
    'label'       => esc_attr__('Archive Portfolio Heading', 'lagi'),
    'description' => esc_attr__('Enter text that displays on archive portfolio pages.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Portfolio', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_single_portfolio_title',
    'label'       => esc_attr__('Single Portfolio Heading', 'lagi'),
    'description' => esc_attr__('Enter text that displays on single portfolio pages. Leave blank to use portfolio title.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Portfolio', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => 'page_title_single_product_title',
    'label'       => esc_attr__('Single Product Heading', 'lagi'),
    'description' => esc_attr__('Enter text that displays on single product pages. Leave blank to use product title.', 'lagi'),
    'section'     => $section,
    'default'     => esc_attr__('Our Shop', 'lagi'),
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));
