<?php
$priority = 1;
$section  = 'mouse';
$prefix   = 'mouse_';

// Mouse
Lagi_Kirki::add_section($section, array(
	'title'    => esc_attr__('Mouse Option', 'lagi'),
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
	'type'     => 'notice',
	'settings' => 'mouse_option',
	'label'    => esc_html__('Mouse Option', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', array(
	'type'        => 'radio-buttonset',
	'settings'    => $prefix . 'style',
	'label'       => esc_html__('Mouse Style', 'lagi'),
	'description' => esc_html__('Display animated helper near the mouse cursor on desktop and notebooks.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => '0',
	'choices'     => array(
		'0' => esc_html__('Hide', 'lagi'),
		'1' => esc_html__('Show', 'lagi'),
	),
));

Lagi_Kirki::add_field('theme', array(
	'type'        => 'radio-buttonset',
	'settings'    => $prefix . 'center_dot',
	'label'       => esc_html__('Center Dot', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => '0',
	'choices'     => array(
		'0' => esc_html__('Hide', 'lagi'),
		'1' => esc_html__('Show', 'lagi'),
	),
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
));

Lagi_Kirki::add_field('theme', array(
	'type'        => 'radio-buttonset',
	'settings'    => $prefix . 'hidden_pointer',
	'label'       => esc_html__('Hidden Pointer', 'lagi'),
	'description' => esc_html__('Hide the default mouse pointer.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => $default[$prefix . 'hidden_pointer'],
	'choices'     => array(
		'all' => esc_html__('No', 'lagi'),
		'none' => esc_html__('Yes', 'lagi'),
	),
	'output'    => array(
		array(
			'element'  => 'body',
			'property' => 'cursor',
		),
	),
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
));

Lagi_Kirki::add_field('theme', array(
	'type'        => 'radio-buttonset',
	'settings'    => $prefix . 'mix_blend_mode',
	'label'       => esc_html__('Mix Blend Mode', 'lagi'),
	'description' => esc_html__('Helps an object blend with the objects below it.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => 'unset',
	'choices'     => array(
		'unset' => esc_html__('No', 'lagi'),
		'difference' => esc_html__('Yes', 'lagi'),
	),
	'output'    => array(
		array(
			'element'  => '.mouse-style',
			'property' => 'mix-blend-mode',
		),
	),
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
));

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => $prefix . 'width',
	'label'     => esc_html__('Width', 'lagi'),
	'section'   => $section,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'width'],
	'choices'   => [
		'min'  => 0,
		'max'  => 100,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => $prefix . 'height',
	'label'     => esc_html__('Height', 'lagi'),
	'section'   => $section,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'height'],
	'choices'   => [
		'min'  => 0,
		'max'  => 100,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => $prefix . 'border_radius',
	'label'     => esc_html__('Border Radius', 'lagi'),
	'section'   => $section,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'border_radius'],
	'choices'   => [
		'min'  => 0,
		'max'  => 100,
		'step' => 1,
	],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => $prefix . 'transition_duration',
	'label'     => esc_html__('Transition Duration', 'lagi'),
	'section'   => $section,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'transition_duration'],
	'choices'   => [
		'min'  => 0,
		'max'  => 2,
		'step' => 0.01,
	],
	'output'    => array(
		array(
			'element'  => '.mouse-style',
			'property' => 'transition-duration',
			'units'    => 's',
		),
	),
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'color-alpha',
	'settings'  => $prefix . 'color',
	'label'     => esc_html__('Color', 'lagi'),
	'section'   => $section,
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'color'],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		],
		[
			'setting'  => $prefix . 'center_dot',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'color-alpha',
	'settings'  => $prefix . 'border_color',
	'label'     => esc_html__('Border Color', 'lagi'),
	'section'   => $section,
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'border_color'],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'color-alpha',
	'settings'  => $prefix . 'background_color',
	'label'     => esc_html__('Background Color', 'lagi'),
	'section'   => $section,
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default[$prefix . 'background_color'],
	'active_callback' => [
		[
			'setting'  => $prefix . 'style',
			'operator' => '==',
			'value'    => '1',
		]
	],
]);
