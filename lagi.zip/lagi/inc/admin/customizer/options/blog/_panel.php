<?php

$panel    = 'blog';
$priority = 1;

// Blog Panel
Lagi_Kirki::add_panel($panel, array(
	'title'    => esc_html__('Blog Option', 'lagi'),
	'priority' => $priority++,
));
