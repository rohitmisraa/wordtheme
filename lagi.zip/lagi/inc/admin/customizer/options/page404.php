<?php
$priority = 1;
$section  = 'page404';
$prefix   = 'page404_';

// Notices
Lagi_Kirki::add_section($section, array(
    'title'    => esc_attr__('404 Page', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'type',
    'label'    => esc_html__('Page 404 Type', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
    'default'  => $default[$prefix . 'type'],
    'choices'  => Lagi_Customize::lagi_get_elementor_library(),
]);

Lagi_Kirki::add_field('theme', array(
    'type'     => 'image',
    'settings' => $prefix . 'image',
    'label'    => esc_html__('Image', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
    'default'   => $default[$prefix . 'image'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'     => 'image',
    'settings' => $prefix . 'bg_image',
    'label'    => esc_html__('Background Image', 'lagi'),
    'section'  => $section,
    'priority' => $priority++,
    'default'   => $default[$prefix . 'bg_image'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => $prefix . 'title',
    'label'       => esc_html__('Title', 'lagi'),
    'section'     => $section,
    'priority'    => $priority++,
    'default'   => $default[$prefix . 'title'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'text',
    'settings'    => $prefix . 'button',
    'label'       => esc_html__('Button', 'lagi'),
    'section'     => $section,
    'priority'    => $priority++,
    'default'   => $default[$prefix . 'button'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));

Lagi_Kirki::add_field('theme', array(
    'type'        => 'editor',
    'settings'    => $prefix . 'text',
    'label'       => esc_html__('Text', 'lagi'),
    'section'     => $section,
    'priority'    => $priority++,
    'default'   => $default[$prefix . 'text'],
    'active_callback' => [
        [
            'setting'  => $prefix . 'type',
            'operator' => '==',
            'value'    => '',
        ]
    ],
));
