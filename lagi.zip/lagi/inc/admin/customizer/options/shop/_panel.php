<?php

$panel    = 'shop';
$priority = 1;

// Shop Panel
Lagi_Kirki::add_panel($panel, array(
	'title'    => esc_html__('Shop Option', 'lagi'),
	'priority' => $priority++,
));
