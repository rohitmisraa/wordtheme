<?php

// Single Product
Lagi_Kirki::add_section('single_product', array(
	'title'    => esc_html__('Single Product', 'lagi'),
	'panel'    => $panel,
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
	'type'     => 'notice',
	'settings' => 'single_product_customize',
	'label'    => esc_html__('Single Product', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
	'type'      => 'radio-image',
	'settings'  => 'single_product_sidebar_position',
	'label'     => esc_html__('Sidebar Layout', 'lagi'),
	'section'   => 'single_product',
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default['single_product_sidebar_position'],
	'choices'   => [
		'left'  => get_template_directory_uri() . '/inc/admin/customizer/assets/images/left-sidebar.png',
		'none'  => get_template_directory_uri() . '/inc/admin/customizer/assets/images/no-sidebar.png',
		'right' => get_template_directory_uri() . '/inc/admin/customizer/assets/images/right-sidebar.png',
	],
]);

Lagi_Kirki::add_field('theme', array(
	'type'            => 'select',
	'settings'        => 'single_product_active_sidebar',
	'label'           => esc_html__('Sidebar', 'lagi'),
	'description'     => esc_html__('Select sidebar that will display on shop archive pages.', 'lagi'),
	'section'         => 'single_product',
	'priority'        => $priority++,
	'default'         => $default['single_product_active_sidebar'],
	'choices'         => Lagi_Helper::get_registered_sidebars(),
	'active_callback' => [
		[
			'setting'  => 'single_product_sidebar_position',
			'operator' => '!==',
			'value'    => 'none',
		]
	],
));

Lagi_Kirki::add_field('theme', [
	'type'      => 'slider',
	'settings'  => 'single_product_sidebar_width',
	'label'     => esc_html__('Sidebar Width', 'lagi'),
	'section'   => 'single_product',
	'priority'  => $priority++,
	'transport' => 'auto',
	'default'   => $default['single_product_sidebar_width'],
	'choices'   => [
		'min'  => 270,
		'max'  => 420,
		'step' => 1,
	],
	'output'    => array(
		array(
			'element'  => '#secondary.sidebar-single-product',
			'property' => 'flex-basis',
			'units'    => 'px',
		),
		array(
			'element'  => '#secondary.sidebar-single-product',
			'property' => 'max-width',
			'units'    => 'px',
		),
	),
	'active_callback' => [
		[
			'setting'  => 'single_product_sidebar_position',
			'operator' => '!==',
			'value'    => 'none',
		],
	],
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'select',
	'settings' => 'single_product_page_title_layout',
	'label'    => esc_html__('Page Title', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_page_title_layout'],
	'choices'  => Lagi_Customize::lagi_get_headers(),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_breadcrumb_enable',
	'label'    => esc_html__('Display Breadcrumb', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_breadcrumb_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_sale_flash_enable',
	'label'    => esc_html__('Display Sale Flash', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_sale_flash_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_images_enable',
	'label'    => esc_html__('Display Images', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_images_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_title_enable',
	'label'    => esc_html__('Display Title', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_title_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_rating_enable',
	'label'    => esc_html__('Display Rating', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_rating_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_price_enable',
	'label'    => esc_html__('Display Price', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_price_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_excerpt_enable',
	'label'    => esc_html__('Display Excerpt', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_excerpt_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_add_to_cart_enable',
	'label'    => esc_html__('Display Button "Add to Cart"', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_add_to_cart_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_meta_enable',
	'label'    => esc_html__('Display Meta', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_meta_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_tabs_enable',
	'label'    => esc_html__('Display Tabs', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_tabs_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_up_sells_enable',
	'label'    => esc_html__('Display Upsells', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_up_sells_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_related_enable',
	'label'    => esc_html__('Display Related', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_related_enable'],
	'choices'  => array(
		'0' => esc_attr__('Hide', 'lagi'),
		'1' => esc_attr__('Show', 'lagi'),
	),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'notice',
	'settings' => 'single_product_header',
	'label'    => esc_attr__('Header', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', array(
	'type'        => 'select',
	'settings'    => 'single_product_header_type',
	'label'       => esc_html__('Header Style', 'lagi'),
	'description' => esc_html__('Select header style that displays on single product page.', 'lagi'),
	'section'     => 'single_product',
	'priority'    => $priority++,
	'default'     => $default['single_product_header_type'],
	'choices'     => Lagi_Customize::lagi_get_headers(),
));

Lagi_Kirki::add_field('theme', array(
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_header_overlay',
	'label'    => esc_html__('Header Overlay', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_header_overlay'],
	'choices'  => array(
		''  => esc_html__('Default', 'lagi'),
		'0' => esc_html__('No', 'lagi'),
		'1' => esc_html__('Yes', 'lagi'),
	),
));

Lagi_Kirki::add_field('theme', array(
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_header_float',
	'label'    => esc_html__('Header Float', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_header_float'],
	'choices'  => array(
		''  => esc_attr__('Default', 'lagi'),
		'0' => esc_attr__('No', 'lagi'),
		'1' => esc_attr__('Yes', 'lagi'),
	),
));

Lagi_Kirki::add_field('theme', array(
	'type'     => 'radio-buttonset',
	'settings' => 'single_product_page_skin',
	'label'    => esc_html__('Page Skin', 'lagi'),
	'section'  => 'single_product',
	'priority' => $priority++,
	'default'  => $default['single_product_page_skin'],
	'choices'  => array(
		''      => esc_html__('Default', 'lagi'),
		'dark'  => esc_html__('Dark', 'lagi'),
		'light' => esc_html__('Light', 'lagi'),
	),
));
