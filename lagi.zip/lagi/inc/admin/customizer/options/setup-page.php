<?php
$priority = 1;
$section = 'setup_page';
$prefix   = 'setup_page_';

// Header
Lagi_Kirki::add_section($section, array(
    'title'    => esc_html__('Setup Page', 'lagi'),
    'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
    'type'     => 'notice',
    'settings' => $prefix . 'notice',
    'label'    => esc_html__('Setup Page', 'lagi'),
    'section'  => $section,
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'sign_in',
    'label'    => esc_html__('Sign In', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'sign_in'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'terms',
    'label'    => esc_html__('Terms & Conditions', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'terms'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'privacy_policy',
    'label'    => esc_html__('Privacy Policy', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'privacy_policy'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'forgot_password',
    'label'    => esc_html__('Forgot Password', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'forgot_password'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
]);

Lagi_Kirki::add_field('theme', [
    'type'     => 'select',
    'settings' => $prefix . 'reset_password',
    'label'    => esc_html__('Reset Password', 'lagi'),
    'section'  => $section,
    'default'  => $default[$prefix . 'reset_password'],
    'choices'  => Lagi_Customize::lagi_get_select_page(),
]);
