<?php

$priority = 1;
$section  = 'io';

// IO Control
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Import / Export', 'lagi'),
	'priority' => 9999,
));

Lagi_Kirki::add_field('theme', [
	'type'        => 'custom',
	'settings'    => 'import_control',
	'label'       => esc_html__('Import', 'lagi'),
	'description' => esc_html__('Click the button below to import the customization settings for this theme.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => '<div class="import-control io-control"><button name="Import" id="lagi-customizer-import" class="button-primary button">' . __('Import', 'lagi') . '</button><input type="file" id="import-file" name="import-file" style="display:none;"/></div>',
]);

Lagi_Kirki::add_field('theme', [
	'type'        => 'custom',
	'settings'    => 'export_control',
	'label'       => esc_html__('Export', 'lagi'),
	'description' => esc_html__('Click the button below to export the customization settings for this theme.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => '<div class="export-control io-control"><a href="' . get_site_url() . '/wp-admin/options.php?page=lagi_export_customizer_options" id="lagi-customizer-export" class="button-primary button">' . __('Export', 'lagi') . '</a></div>',
]);

if (WP_DEBUG) {
	Lagi_Kirki::add_field('theme', [
		'type'        => 'custom',
		'settings'    => 'export_demo_control',
		'label'       => esc_html__('Export for Demo', 'lagi'),
		'description' => esc_html__('Click the button below to export the customization settings for this theme.', 'lagi'),
		'section'     => $section,
		'priority'    => $priority++,
		'default'     => '<div class="export-control io-control"><form action=""><input type="submit" class="button-primary button" name="export" value="' . __('Export', 'lagi') . '"/></form></div>',
	]);
}

Lagi_Kirki::add_field('theme', array(
	'type'        => 'custom',
	'settings'    => 'reset_control',
	'label'       => esc_html__('Reset', 'lagi'),
	'description' => esc_html__('Click the button below to reset the customization settings for this theme.', 'lagi'),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => '<div class="reset-control io-control"><button name="Reset" id="lagi-customizer-reset" class="button-primary button">' . __('Reset Options', 'lagi') . '</button></div>',
));
