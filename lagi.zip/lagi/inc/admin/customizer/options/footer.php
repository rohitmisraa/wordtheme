<?php

$priority = 1;
$section  = 'footer';
$prefix   = 'footer_';

// Footer
Lagi_Kirki::add_section($section, array(
	'title'    => esc_html__('Footer Option', 'lagi'),
	'priority' => $priority++,
));

Lagi_Kirki::add_field('theme', [
	'type'     => 'notice',
	'settings' => $prefix . 'notice',
	'label'    => esc_html__('Footer Customize', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'select',
	'settings' => $prefix . 'type',
	'label'    => esc_html__('Footer Type', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'type'],
	'choices'  => Lagi_Customize::lagi_get_footers(),
]);

Lagi_Kirki::add_field('theme', [
	'type'     => 'text',
	'settings' => $prefix . 'copyright_text',
	'label'    => esc_html__('Copyright', 'lagi'),
	'section'  => $section,
	'priority' => $priority++,
	'default'  => $default[$prefix . 'copyright_text'],
	'active_callback' => [
		[
			'setting'  => $prefix . 'type',
			'operator' => '==',
			'value'    => '',
		]
	],
]);
