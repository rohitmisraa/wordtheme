<div class="section-lagi section-changelog">
    <div class="entry-heading">
        <h4><?php esc_html_e('Changelogs', 'lagi'); ?></h4>
    </div>

    <div class="wrap-content">
        <table class="table-changelogs">
            <thead>
                <tr>
                    <th><?php esc_html_e('Version', 'lagi'); ?></th>
                    <th><?php esc_html_e('Description', 'lagi'); ?></th>
                    <th><?php esc_html_e('Date', 'lagi'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php echo Lagi_Panel::get_changelogs(true); ?>
            </tbody>
        </table>
    </div><!-- end .wrap-content -->
</div>