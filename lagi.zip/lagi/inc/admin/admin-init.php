<?php

/**
 * Lagi Admin Engine Room.
 * This is where all Admin Functions run
 *
 * @package lagi
 */

/**
 * Theme Panel
 */
require LAGI_THEME_DIR . '/inc/admin/panel/panel.php';

/**
 * Theme Wizard
 */
if (!is_customize_preview() && is_admin()) {
	/**
	 * Theme Options
	 */
	require LAGI_THEME_DIR . '/inc/admin/advanced/index.php';

	// Include Merlin
	require_once LAGI_THEME_DIR . '/inc/admin/merlin/vendor/autoload.php';
	require_once LAGI_THEME_DIR . '/inc/admin/merlin/class-merlin.php';
	require_once LAGI_THEME_DIR . '/inc/admin/merlin/merlin-config.php';
	require_once LAGI_THEME_DIR . '/inc/admin/merlin/merlin-filters.php';
	require_once LAGI_THEME_DIR . '/inc/admin/merlin/lagi-merlin.php';
}

/**
 * Include Kirki
 */
require_once dirname(__FILE__) . '/kirki/kirki.php';

/**
 * Theme Customizer
 */
require_once LAGI_CUSTOMIZER_DIR . '/customizer.php';
