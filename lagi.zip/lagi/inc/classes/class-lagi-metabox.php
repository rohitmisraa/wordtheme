<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Metabox')) {
	class Lagi_Metabox
	{

		protected static $instance = null;

		public static function instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize()
		{
			add_filter('uxper_metabox_meta_boxes', array($this, 'register_meta_boxes'));
		}

		/**
		 * Register Metabox
		 *
		 * @param $meta_boxes
		 *
		 * @return array
		 */
		public function register_meta_boxes($meta_boxes)
		{
			$page_registered_sidebars = Lagi_Helper::get_registered_sidebars(true);

			$general_options = array(
				array(
					'title'  => esc_attr__('Layout', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'site_layout',
							'type'    => 'select',
							'title'   => esc_html__('Layout', 'lagi'),
							'desc'    => esc_html__('Controls the layout of this page.', 'lagi'),
							'options' => array(
								''          => esc_attr__('Default', 'lagi'),
								'boxed'     => esc_attr__('Boxed', 'lagi'),
								'fullwidth' => esc_attr__('Full Width', 'lagi'),
							),
							'default' => '',
						),
						array(
							'id'      => 'page_skin',
							'type'    => 'select',
							'title'   => esc_attr__('Site Skin', 'lagi'),
							'default' => '',
							'options' => array(
								''      => esc_html__('Default', 'lagi'),
								'dark'  => esc_html__('Dark', 'lagi'),
								'light' => esc_html__('Light', 'lagi'),
							),
						),
						array(
							'id'    => 'site_width',
							'type'  => 'text',
							'title' => esc_html__('Site Width', 'lagi'),
							'desc'  => esc_html__('Controls the site width for this page. Enter value including any valid CSS unit. For e.g: 1200px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'site_top_spacing',
							'type'  => 'text',
							'title' => esc_html__('Site Top Spacing', 'lagi'),
							'desc'  => esc_html__('Controls the top spacing of this page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'site_bottom_spacing',
							'type'  => 'text',
							'title' => esc_html__('Site Bottom Spacing', 'lagi'),
							'desc'  => esc_html__('Controls the bottom spacing of this page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'body_class',
							'type'  => 'text',
							'title' => esc_html__('Body Class', 'lagi'),
							'desc'  => esc_html__('Add a class name to body then refer to it in custom CSS.', 'lagi'),
						),
						array(
							'id'    => 'content_top_spacing',
							'type'  => 'text',
							'title' => esc_html__('Content Top Spacing', 'lagi'),
							'desc'  => esc_html__('Controls the top spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'content_bottom_spacing',
							'type'  => 'text',
							'title' => esc_html__('Content Bottom Spacing', 'lagi'),
							'desc'  => esc_html__('Controls the bottom spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'content_top_spacing_tablet',
							'type'  => 'text',
							'title' => esc_html__('Content Top Spacing Tablet', 'lagi'),
							'desc'  => esc_html__('Controls the top spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'content_bottom_spacing_tablet',
							'type'  => 'text',
							'title' => esc_html__('Content Bottom Spacing Tablet', 'lagi'),
							'desc'  => esc_html__('Controls the bottom spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'content_top_spacing_mobile',
							'type'  => 'text',
							'title' => esc_html__('Content Top Spacing Mobile', 'lagi'),
							'desc'  => esc_html__('Controls the top spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'    => 'content_bottom_spacing_mobile',
							'type'  => 'text',
							'title' => esc_html__('Content Bottom Spacing Mobile', 'lagi'),
							'desc'  => esc_html__('Controls the bottom spacing of content page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'      => 'content_overflow_hidden',
							'type'    => 'select',
							'title'   => esc_html__('Overflow Hidden', 'lagi'),
							'default' => 'inherit',
							'options' => array(
								'hidden'     => esc_html__('Yes', 'lagi'),
								'inherit' => esc_html__('No', 'lagi'),
							),
						),
					),
				),
				array(
					'title'  => esc_attr__('Background', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'site_background_message',
							'type'    => 'message',
							'title'   => esc_html__('Background Boxed', 'lagi'),
							'message' => esc_html__('These options controls the background on boxed mode.', 'lagi'),
						),
						array(
							'id'    => 'site_background_color',
							'type'  => 'color',
							'title' => esc_html__('Background Color', 'lagi'),
							'desc'  => esc_html__('Controls the background color of the outer background area in boxed mode of this page.', 'lagi'),
						),
						array(
							'id'    => 'site_background_image',
							'type'  => 'media',
							'title' => esc_html__('Background Image', 'lagi'),
							'desc'  => esc_html__('Controls the background image of the outer background area in boxed mode of this page.', 'lagi'),
						),
						array(
							'id'      => 'site_background_repeat',
							'type'    => 'select',
							'title'   => esc_html__('Background Repeat', 'lagi'),
							'desc'    => esc_html__('Controls the background repeat of the outer background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								'no-repeat' => esc_attr__('No repeat', 'lagi'),
								'repeat'    => esc_attr__('Repeat', 'lagi'),
								'repeat-x'  => esc_attr__('Repeat X', 'lagi'),
								'repeat-y'  => esc_attr__('Repeat Y', 'lagi'),
							),
						),
						array(
							'id'      => 'site_background_attachment',
							'type'    => 'select',
							'title'   => esc_html__('Background Attachment', 'lagi'),
							'desc'    => esc_html__('Controls the background attachment of the outer background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								''       => esc_attr__('Default', 'lagi'),
								'fixed'  => esc_attr__('Fixed', 'lagi'),
								'scroll' => esc_attr__('Scroll', 'lagi'),
							),
						),
						array(
							'id'      => 'site_background_position',
							'type'    => 'select',
							'title'   => esc_html__('Background Position', 'lagi'),
							'desc'    => esc_html__('Controls the background position of the outer background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								''              => esc_attr__('Default', 'lagi'),
								'left top'      => esc_attr__('Left Top', 'lagi'),
								'left center'   => esc_attr__('Left Center', 'lagi'),
								'left bottom'   => esc_attr__('Left Bottom', 'lagi'),
								'right top'     => esc_attr__('Right Top', 'lagi'),
								'right center'  => esc_attr__('Right Center', 'lagi'),
								'right bottom'  => esc_attr__('Right Bottom', 'lagi'),
								'center top'    => esc_attr__('Center Top', 'lagi'),
								'center center' => esc_attr__('Center Center', 'lagi'),
								'center bottom' => esc_attr__('Center Bottom', 'lagi'),
							),
						),
						array(
							'id'      => 'site_background_size',
							'type'    => 'select',
							'title'   => esc_html__('Background Size', 'lagi'),
							'desc'    => esc_html__('Controls the background size of the outer background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								''        => esc_attr__('Default', 'lagi'),
								'auto'    => esc_attr__('Auto', 'lagi'),
								'cover'   => esc_attr__('Cover', 'lagi'),
								'contain' => esc_attr__('Contain', 'lagi'),
								'initial' => esc_attr__('Initial', 'lagi'),
							),
						),
						array(
							'id'      => 'content_background_message',
							'type'    => 'message',
							'title'   => esc_html__('Background Content', 'lagi'),
							'message' => esc_html__('These options controls the background of main content on this page.', 'lagi'),
						),
						array(
							'id'    => 'content_background_color',
							'type'  => 'color',
							'title' => esc_html__('Background Color', 'lagi'),
							'desc'  => esc_html__('Controls the background color of main content on this page.', 'lagi'),
						),
						array(
							'id'    => 'content_background_image',
							'type'  => 'media',
							'title' => esc_html__('Background Image', 'lagi'),
							'desc'  => esc_html__('Controls the background image of main content on this page.', 'lagi'),
						),
						array(
							'id'      => 'content_background_repeat',
							'type'    => 'select',
							'title'   => esc_html__('Background Repeat', 'lagi'),
							'desc'    => esc_html__('Controls the background repeat of main content on this page.', 'lagi'),
							'options' => array(
								'no-repeat' => esc_attr__('No repeat', 'lagi'),
								'repeat'    => esc_attr__('Repeat', 'lagi'),
								'repeat-x'  => esc_attr__('Repeat X', 'lagi'),
								'repeat-y'  => esc_attr__('Repeat Y', 'lagi'),
							),
						),
						array(
							'id'      => 'content_background_attachment',
							'type'    => 'select',
							'title'   => esc_html__('Background Attachment', 'lagi'),
							'desc'    => esc_html__('Controls the background attachment of the inner background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								''       => esc_attr__('Default', 'lagi'),
								'fixed'  => esc_attr__('Fixed', 'lagi'),
								'scroll' => esc_attr__('Scroll', 'lagi'),
							),
						),
						array(
							'id'      => 'content_background_position',
							'type'    => 'select',
							'title'   => esc_html__('Background Position', 'lagi'),
							'desc'    => esc_html__('Controls the background position of main content on this page.', 'lagi'),
							'options' => array(
								''              => esc_attr__('Default', 'lagi'),
								'left top'      => esc_attr__('Left Top', 'lagi'),
								'left center'   => esc_attr__('Left Center', 'lagi'),
								'left bottom'   => esc_attr__('Left Bottom', 'lagi'),
								'right top'     => esc_attr__('Right Top', 'lagi'),
								'right center'  => esc_attr__('Right Center', 'lagi'),
								'right bottom'  => esc_attr__('Right Bottom', 'lagi'),
								'center top'    => esc_attr__('Center Top', 'lagi'),
								'center center' => esc_attr__('Center Center', 'lagi'),
								'center bottom' => esc_attr__('Center Bottom', 'lagi'),
							),
						),
						array(
							'id'      => 'content_background_size',
							'type'    => 'select',
							'title'   => esc_html__('Background Size', 'lagi'),
							'desc'    => esc_html__('Controls the background size of the inner background area in boxed mode of this page.', 'lagi'),
							'options' => array(
								''        => esc_attr__('Default', 'lagi'),
								'auto'    => esc_attr__('Auto', 'lagi'),
								'cover'   => esc_attr__('Cover', 'lagi'),
								'contain' => esc_attr__('Contain', 'lagi'),
								'initial' => esc_attr__('Initial', 'lagi'),
							),
						),
					),
				),
				array(
					'title'  => esc_html__('Header', 'lagi'),
					'fields' => array(
						array(
							'id'    => 'header_type',
							'type'  => 'select',
							'title' => esc_attr__('Header Type', 'lagi'),
							'desc'  => wp_kses(
								sprintf(
									__('Select header type that displays on this page. When you choose Default, the value in %s will be used.', 'lagi'),
									'<a href="' . admin_url('/customize.php?autofocus[section]=header') . '">Customize</a>'
								),
								'lagi-a'
							),
							'default' => '',
							'options' => Lagi_Global::get_list_headers(),
						),
						array(
							'id'      => 'header_overlay',
							'type'    => 'select',
							'title'   => esc_attr__('Header Overlay', 'lagi'),
							'default' => '',
							'options' => array(
								''  => esc_html__('Default', 'lagi'),
								'0' => esc_html__('No', 'lagi'),
								'1' => esc_html__('Yes', 'lagi'),
							),
						),
						array(
							'id'      => 'header_float',
							'type'    => 'select',
							'title'   => esc_attr__('Header Float', 'lagi'),
							'default' => '',
							'options' => array(
								''  => esc_html__('Default', 'lagi'),
								'0' => esc_html__('No', 'lagi'),
								'1' => esc_html__('Yes', 'lagi'),
							),
						),
						array(
							'id'      => 'header_skin',
							'type'    => 'select',
							'title'   => esc_attr__('Header Skin', 'lagi'),
							'default' => '',
							'options' => array(
								''      => esc_html__('Default', 'lagi'),
								'dark'  => esc_html__('Dark', 'lagi'),
								'light' => esc_html__('Light', 'lagi'),
							),
						),
						array(
							'id'      => 'custom_dark_logo',
							'type'    => 'media',
							'title'   => esc_html__('Custom Dark Logo', 'lagi'),
							'desc'    => esc_html__('Select custom dark logo for this page.', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'custom_light_logo',
							'type'    => 'media',
							'title'   => esc_html__('Custom Light Logo', 'lagi'),
							'desc'    => esc_html__('Select custom light logo for this page.', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'custom_logo_width',
							'type'    => 'text',
							'title'   => esc_html__('Custom Logo Width', 'lagi'),
							'desc'    => esc_html__('Controls the width of logo. For e.g: 150px', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'custom_sticky_logo_width',
							'type'    => 'text',
							'title'   => esc_html__('Custom Sticky Logo Width', 'lagi'),
							'desc'    => esc_html__('Controls the width of sticky logo. For e.g: 150px', 'lagi'),
							'default' => '',
						),
					),
				),
				array(
					'title'  => esc_html__('Page Title', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'page_page_title_layout',
							'type'    => 'select',
							'title'   => esc_html__('Layout', 'lagi'),
							'default' => '',
							'options' => Lagi_Global::get_list_page_titles(),
						),
						array(
							'id'    => 'page_page_title_bottom_spacing',
							'type'  => 'text',
							'title' => esc_html__('Spacing', 'lagi'),
							'desc'  => esc_html__('Controls the bottom spacing of page title of this page. Enter value including any valid CSS unit. For e.g: 50px. Leave blank to use global setting.', 'lagi'),
						),
						array(
							'id'      => 'page_page_title_background_color',
							'type'    => 'color',
							'title'   => esc_html__('Background Color', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'page_page_title_color',
							'type'    => 'color',
							'title'   => esc_html__('Color', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'page_page_title_breadcrumb_color',
							'type'    => 'color',
							'title'   => esc_html__('Breadcrumb Color', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'page_page_title_breadcrumb_link_color',
							'type'    => 'color',
							'title'   => esc_html__('Breadcrumb Link Color', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'page_page_title_background',
							'type'    => 'media',
							'title'   => esc_html__('Background Image', 'lagi'),
							'default' => '',
						),
						array(
							'id'      => 'page_page_title_background_overlay',
							'type'    => 'color',
							'title'   => esc_html__('Background Overlay', 'lagi'),
							'default' => '',
						),
						array(
							'id'    => 'page_page_title_custom_heading',
							'type'  => 'text',
							'title' => esc_html__('Custom Heading Text', 'lagi'),
							'desc'  => esc_html__('Insert custom heading for the page title. Leave blank to use default.', 'lagi'),
						),
						array(
							'id'    => 'page_page_title_custom_sub_heading',
							'type'  => 'text',
							'title' => esc_html__('Custom Sub Heading Text', 'lagi'),
							'desc'  => esc_html__('Insert custom sub heading for the page title. Leave blank to use default.', 'lagi'),
						),
					),
				),
				array(
					'title'  => esc_html__('Sidebars', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'active_sidebar',
							'type'    => 'select',
							'title'   => esc_html__('Sidebar', 'lagi'),
							'desc'    => esc_html__('Select sidebar that will display on this page.', 'lagi'),
							'default' => 'default',
							'options' => $page_registered_sidebars,
						),
						array(
							'id'    => 'sidebar_position',
							'type'  => 'switch',
							'title' => esc_html__('Sidebar Position', 'lagi'),
							'desc'  => esc_html__('Select position of Sidebar for this page.', 'lagi'),
							'default' => 'default',
							'options' => array(
								'left'    => esc_html__('Left', 'lagi'),
								'right'   => esc_html__('Right', 'lagi'),
								'default' => esc_html__('Default', 'lagi'),
							),
						),
					),
				),
				array(
					'title'  => esc_html__('Footer', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'footer_enable',
							'type'    => 'select',
							'title'   => esc_html__('Footer Enable', 'lagi'),
							'default' => '',
							'options' => array(
								''     => esc_html__('Yes', 'lagi'),
								'none' => esc_html__('No', 'lagi'),
							),
						),
						array(
							'id'    => 'footer_type',
							'type'  => 'select',
							'title' => esc_attr__('Footer Type', 'lagi'),
							'desc'  => '',
							'default' => '',
							'options' => Lagi_Global::get_list_footers(true),
						),
					),
				),
			);

			$portfolio_options = array(
				array(
					'title'  => esc_html__('Gallery', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'portfolio_content_gallery',
							'type'    => 'gallery',
							'title'   => esc_html__('Portfolio Content Gallery', 'lagi'),
							'default' => '',
						),
					),
				),
				array(
					'title'  => esc_html__('Video', 'lagi'),
					'fields' => array(
						array(
							'id'      	=> 'portfolio_video_thumbnail',
							'type'    	=> 'media',
							'title'   	=> esc_html__('Portfolio Video Thumbnail', 'lagi'),
							'default' 	=> LAGI_THEME_DIR . '/assets/images/no-image.jpg',
						),
						array(
							'id'      	=> 'portfolio_video_url',
							'type'    	=> 'text',
							'title'   	=> esc_html__('Portfolio Video Url', 'lagi'),
							'default' 	=> '',
							'desc'		=> 'Enter Url Video',
						),
					),
				),
				array(
					'title'  => esc_html__('More Info', 'lagi'),
					'fields' => array(
						array(
							'id'      => 'portfolio_content_client',
							'type'    => 'text',
							'title'   => esc_html__('Portfolio Content Client', 'lagi'),
							'default' => '',
						),
						array(
							'id'      	=> 'portfolio_content_website',
							'type'    	=> 'text',
							'title'   	=> esc_html__('Portfolio Content Website', 'lagi'),
							'default' 	=> '',
							'desc'		=> 'Enter Url Your Website'
						),
					),
				),
			);

			// Page
			$meta_boxes[] = array(
				'id'         => 'lagi_page_options',
				'title'      => esc_html__('Page Options', 'lagi'),
				'post_types' => array('page', 'post', 'product', 'portfolio'),
				'context'    => 'normal',
				'priority'   => 'high',
				'fields'     => array(
					array(
						'type'  => 'tabpanel',
						'items' => $general_options,
					),
				),
			);

			$meta_boxes[] = array(
				'id'         => 'lagi_portfolio_options',
				'title'      => esc_html__('Portfolio Options', 'lagi'),
				'post_types' => array('portfolio'),
				'context'    => 'normal',
				'priority'   => 'high',
				'fields'     => array(
					array(
						'type'  => 'tabpanel',
						'items' => $portfolio_options,
					),
				),
			);

			return $meta_boxes;
		}
	}

	Lagi_Metabox::instance()->initialize();
}
