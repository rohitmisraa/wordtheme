<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Hook action
 */
if (!class_exists('Lagi_Hook')) {

	class Lagi_Hook
	{
		/**
		 * The constructor.
		 */
		function __construct()
		{
			add_action('lagi_after_body_open', array($this, 'pre_loader'));
			add_action('lagi_after_footer', array($this, 'global_template'));
		}

		/**
		 * Register global template
		 */
		public static function pre_loader()
		{
			get_template_part('templates/global/site-loading');
		}

		/**
		 * Register global template
		 */
		public static function global_template()
		{
			self::scroll_top();
			self::content_protected();
			self::color_mode_switcher();
		}

		public static function scroll_top()
		{
			$scroll_top_enable = Lagi_Helper::setting('scroll_top_enable');

			if (!$scroll_top_enable) {
				return;
			}
?>
			<a class="page-scroll-up" id="page-scroll-up">
				<i class="arrow-top fal fa-angle-up"></i>
				<i class="arrow-bottom fal fa-angle-up"></i>
			</a>
		<?php
		}

		public static function content_protected()
		{
			$content_protected = Lagi_Helper::setting('content_protected_enable');

			if (!$content_protected) {
				return;
			}
		?>
			<div id="lagi-content-protected-box" class="lagi-content-protected-box">
				<?php printf(esc_html__(
					'%sAlert:%s You are not allowed to copy content or view source !!',
					'lagi'
				), '<span class="alert-label">', '</span>'); ?>
			</div>
		<?php
		}

		public static function color_mode_switcher()
		{
			$enable_color_mode	= Lagi_Helper::setting('enable_color_mode');
			$default_color_mode = Lagi_Helper::setting('default_color_mode');
			$page_skin          = Lagi_Helper::get_post_meta('page_skin', '');

			if ($enable_color_mode !== '1') {
				return;
			}

			$classes = array('lagi-mode-switcher');
			if ($page_skin !== '') {
				if ($page_skin === 'dark') {
					$classes[] = 'lagi-dark-scheme';
				} elseif ($page_skin === 'light') {
					$classes[] = 'lagi-light-scheme';
				}
			} else {
				if ($default_color_mode === 'dark') {
					$classes[] = 'lagi-dark-scheme';
				} elseif ($default_color_mode === 'light') {
					$classes[] = 'lagi-light-scheme';
				}
			}
		?>
			<div class="lagi-mode-switcher-wrap">
				<div class="<?php echo join(' ', $classes); ?>">
					<div class="lagi-mode-switcher-item lagi-dark-scheme">
						<p class="lagi-mode-switcher-item-state"><?php esc_html_e('Dark', 'lagi'); ?></p>
					</div>
					<div class="lagi-mode-switcher-item lagi-light-scheme">
						<p class="lagi-mode-switcher-item-state"><?php esc_html_e('Light', 'lagi'); ?></p>
					</div>
					<div class="lagi-mode-switcher-toddler">
						<div class="lagi-mode-switcher-toddler-wrap">
							<div class="lagi-mode-switcher-toddler-item lagi-dark-scheme">
								<p class="lagi-mode-switcher-item-state"><?php esc_html_e('Dark', 'lagi'); ?></p>
							</div>
							<div class="lagi-mode-switcher-toddler-item lagi-light-scheme">
								<p class="lagi-mode-switcher-item-state"><?php esc_html_e('Light', 'lagi'); ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
		}
	}

	new Lagi_Hook();
}
