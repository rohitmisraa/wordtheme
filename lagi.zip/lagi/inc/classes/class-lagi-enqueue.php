<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('Lagi_Enqueue')) {

	/**
	 *  Class Lagi_Enqueue
	 */
	class Lagi_Enqueue
	{

		/**
		 * The constructor.
		 */
		function __construct()
		{
			add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
			add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
		}

		/**
		 * Register the stylesheets for the public-facing side of the site.
		 */
		public function enqueue_styles()
		{
			/*
			 * Enqueue Third Party Styles
			 */
			wp_enqueue_style('font-awesome-all', LAGI_THEME_URI . '/assets/fonts/font-awesome/css/fontawesome-all.min.css', array(), '5.10.0', 'all');

			wp_enqueue_style('swiper', LAGI_THEME_URI . '/assets/libs/swiper/css/swiper.min.css', array(), '10.3.1', 'all');

			wp_enqueue_style('growl', LAGI_THEME_URI . '/assets/libs/growl/css/jquery.growl.min.css', array(), '1.3.3', 'all');

			wp_enqueue_style('nice-select', LAGI_THEME_URI . '/assets/libs/jquery-nice-select/css/nice-select.css', array(), '1.1.0', 'all');

			/*
			 * Enqueue Theme Styles
			 */
			wp_enqueue_style('lagi-font-inter', LAGI_THEME_URI . '/assets/fonts/inter/font.min.css', null, null);
			wp_enqueue_style('lagi-font-outfit', LAGI_THEME_URI . '/assets/fonts/outfit/font.min.css', null, null);

			$type   = Lagi_Global::get_header_type();
			$header = 'header-' . $type;
			$header = $header . '.css';
			$upload_dir = wp_upload_dir();
			$logger_dir = $upload_dir['baseurl'] . '/lagi/header/';
			if (Lagi_Helper::check_file_base('header-' . $type, 'css')) {
				wp_enqueue_style('lagi-header-style', $logger_dir . $header);
			}

			if (is_rtl()) {
				wp_enqueue_style('lagi-style', get_template_directory_uri() . '/assets/css/lagi-rtl.css');
				wp_enqueue_style('lagi-rtl-style-custom', get_template_directory_uri() . '/assets/css/lagi-rtl-custom.css');
			} else {
				$enable = Lagi_Helper::setting('performance_disable_style_css');
				if ($enable !== true) {
					wp_enqueue_style('lagi-style', get_template_directory_uri() . '/assets/scss/style.css');
				}
			}
		}

		/**
		 * Register the JavaScript for the admin area.
		 */
		public function enqueue_scripts()
		{
			/*
			 * Register Scripts
            */

			wp_enqueue_script('isotope', LAGI_THEME_URI . '/assets/libs/isotope/js/isotope.pkgd.min.js', array('jquery'), '3.0.6', true);

			wp_enqueue_script('infinite-scroll', LAGI_THEME_URI . '/assets/libs/infinite-scroll/infinite-scroll.pkgd.min.js', array('jquery'), '3.0.6', true);

			wp_enqueue_script('packery', LAGI_THEME_URI . '/assets/libs/packery/packery-mode.pkgd.min.js', array('jquery'), '2.0.1', true);

			wp_enqueue_script('swiper', LAGI_THEME_URI . '/assets/libs/swiper/js/swiper.min.js', array('jquery'), '10.3.1', true);

			wp_enqueue_script('growl', LAGI_THEME_URI . '/assets/libs/growl/js/jquery.growl.min.js', array('jquery'), '1.3.3', true);

			wp_enqueue_script('waypoints', LAGI_THEME_URI . '/assets/libs/waypoints/jquery.waypoints.js', array('jquery'), '4.0.1', true);

			$enable_smooth_scroll = Lagi_Helper::setting('smooth_scroll_enable');
			if ($enable_smooth_scroll == true) {
				wp_enqueue_script('smooth-scroll', LAGI_THEME_URI . '/assets/libs/smooth-scroll/SmoothScroll.min.js', array('jquery'), '1.4.9', true);
			}

			wp_enqueue_script('jquery-smooth-scroll', LAGI_THEME_URI . '/assets/libs/smooth-scroll/jquery.smooth-scroll.min.js', array('jquery'), '2.2.0', true);

			wp_enqueue_script('validate', LAGI_THEME_URI . '/assets/libs/validate/jquery.validate.min.js', array('jquery'), '2.2.0', true);

			wp_enqueue_script('nice-select', LAGI_THEME_URI . '/assets/libs/jquery-nice-select/js/jquery.nice-select.min.js', array('swiper'), LAGI_THEME_VERSION, true);

			/*
			 * Register Theme Scripts
			 */
			wp_enqueue_script('lagi-custom-js', LAGI_THEME_URI . '/assets/js/custom.js', array('jquery'), LAGI_THEME_VERSION, true);

			$ajax_url     = admin_url('admin-ajax.php');
			$current_lang = apply_filters('wpml_current_language', null);

			if ($current_lang) {
				$ajax_url = add_query_arg('lang', $current_lang, $ajax_url);
			}

			wp_localize_script(
				'lagi-custom-js',
				'theme_vars',
				array(
					'ajax_url'                 	=> esc_url($ajax_url),
					'header_sticky'            	=> Lagi_Global::get_header_overlay(),
					'content_protected_enable' 	=> Lagi_Helper::setting('content_protected_enable'),
					'scroll_top_enable'        	=> Lagi_Helper::setting('scroll_top_enable'),
					'send_user_info' 			=> esc_html__('Sending user info,please wait...', 'lagi'),
					'notice_cookie_enable'      => Lagi_Helper::setting('notice_cookie_enable'),
					'notice_cookie_confirm'     => isset($_COOKIE['notice_cookie_confirm']) ? 'yes' : 'no',
					'notice_cookie_messages'    => Lagi_Notices::instance()->get_notice_cookie_messages(),
					'prevText' 					=> esc_html__('Prev', 'lagi'),
					'nextText' 					=> esc_html__('Next', 'lagi'),
				)
			);

			/*
			 * The comment-reply script.
			 */
			if (is_singular() && comments_open() && get_option('thread_comments')) {
				wp_enqueue_script('comment-reply');
			}
		}
	}

	new Lagi_Enqueue();
}
