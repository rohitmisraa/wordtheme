<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Job')) {

	class Lagi_Job
	{

		protected static $instance  = null;
		protected static $post_type = 'job';
		protected static $tag       = 'job_tags';
		protected static $category  = 'job_category';

		public static function instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize()
		{
			$this->register_post_type();
			$this->register_taxonomy_category();
			$this->register_taxonomy_tag();
			add_action('wp_ajax_job_infinite_load', array($this, 'infinite_load'));
			add_action('wp_ajax_nopriv_job_infinite_load', array($this, 'infinite_load'));
		}

		protected function register_post_type()
		{
			$labels = array(
				'name'               => __('Jobs', 'lagi'),
				'singular_name'      => __('Job', 'lagi'),
				'add_new'            => __('Add New', 'lagi'),
				'add_new_item'       => __('Add New', 'lagi'),
				'edit_item'          => __('Edit job', 'lagi'),
				'new_item'           => __('Add New job', 'lagi'),
				'view_item'          => __('View job', 'lagi'),
				'search_items'       => __('Search job', 'lagi'),
				'not_found'          => __('No items found', 'lagi'),
				'not_found_in_trash' => __('No items found in trash', 'lagi'),
			);

			$args = array(
				'menu_icon' => 'dashicons-id-alt',
				'labels'    => $labels,
				'public'    => true,
				'supports'  => array(
					'title',
					'editor',
					'post-formats',
					'excerpt',
					'thumbnail',
					'comments',
					'author',
					'custom-fields',
					'revisions',
				),
				'rewrite'           => array('slug' => 'job', 'with_front' => false),
				'capability_type' => 'page',
				'menu_position'   => 5,
				'hierarchical'    => true,
				'has_archive'     => true,
				'show_in_rest' 		=> true,
			);

			$args = apply_filters('job_args', $args);
			register_post_type('job', $args);
		}

		public function infinite_load()
		{
			$layout          = isset($_POST['layout']) ? $_POST['layout'] : '';
			$query_vars      = isset($_POST['query_vars']) ? $_POST['query_vars'] : '';
			$pagination_type = isset($_POST['pagination_type']) ? $_POST['pagination_type'] : '';
			$widget_query    = isset($_POST['widget_query']) ? $_POST['widget_query'] : '';
			$settings        = isset($_POST['settings']) ? $_POST['settings'] : '';

			$query_vars['no_found_rows'] = false;
			$query_vars['nopaging'] = false;

			$lagi_query = new WP_Query($query_vars);

			$response = array(
				'max_num_pages' => $lagi_query->max_num_pages,
				'found_posts'   => $lagi_query->found_posts,
				'count'         => $lagi_query->post_count,
			);

			if (!empty($settings['pagination_type'])) {
				$pagination_type = $settings['pagination_type'];
			}

			if ($pagination_type == 'navigation') {
				$links = paginate_links(array(
					'total'     => $lagi_query->max_num_pages,
					'current'   => $query_vars['paged'],
					'prev_text' => '<i class="far fa-long-arrow-left"></i>',
					'next_text' => '<i class="far fa-long-arrow-right"></i>',
					'type'      => 'list',
					'end_size'  => 1,
					'mid_size'  => 1,
				));
				$pagination = wp_kses($links, Lagi_Helper::lagi_kses_allowed_html());
				$response['pagination'] = $pagination;
			}

			ob_start();

			if ($widget_query && !empty($settings)) {

				if ($lagi_query->have_posts()) :

					set_query_var('lagi_query', $lagi_query);
					set_query_var('settings', $settings);

					get_template_part('templates/loop/widgets/job/content', $settings['layout']);

					wp_reset_postdata();

				endif;
			} else {
				if ($lagi_query->have_posts()) :

					while ($lagi_query->have_posts()) : $lagi_query->the_post();

						get_template_part('templates/loop/job/content', $settings['layout']);

					endwhile;

					wp_reset_postdata();
				endif;
			}

			$template = ob_get_contents();
			ob_clean();

			$response['template'] = $template;

			echo json_encode($response);

			wp_die();
		}

		/**
		 * Register a taxonomy for Featured Item Tags.
		 *
		 * @link http://codex.wordpress.org/Function_Reference/register_taxonomy
		 */
		protected function register_taxonomy_tag()
		{
			$labels = array(
				'name'                       => __('Tags', 'lagi'),
				'singular_name'              => __('Tag', 'lagi'),
				'menu_name'                  => __('Tags', 'lagi'),
				'edit_item'                  => __('Edit Tag', 'lagi'),
				'update_item'                => __('Update Tag', 'lagi'),
				'add_new_item'               => __('Add New Tag', 'lagi'),
				'new_item_name'              => __('New  Tag Name', 'lagi'),
				'parent_item'                => __('Parent Tag', 'lagi'),
				'parent_item_colon'          => __('Parent Tag:', 'lagi'),
				'all_items'                  => __('All Tags', 'lagi'),
				'search_items'               => __('Search  Tags', 'lagi'),
				'popular_items'              => __('Popular Tags', 'lagi'),
				'separate_items_with_commas' => __('Separate tags with commas', 'lagi'),
				'add_or_remove_items'        => __('Add or remove tags', 'lagi'),
				'choose_from_most_used'      => __('Choose from the most used tags', 'lagi'),
				'not_found'                  => __('No  tags found.', 'lagi'),
			);

			$args = array(
				'labels'            => $labels,
				'public'            => true,
				'show_in_nav_menus' => true,
				'show_ui'           => true,
				'show_tagcloud'     => true,
				'hierarchical'      => false,
				'rewrite'           => array('slug' => 'job_tag', 'with_front' => false),
				'show_admin_column' => true,
				'query_var'         => true,
				'show_in_rest' 		=> true,
			);

			$args = apply_filters('job_tag_args', $args);
			register_taxonomy('job_tag', array('job'), $args);
		}

		/**
		 * Register a taxonomy for Featured Item Categories.
		 *
		 * @link http://codex.wordpress.org/Function_Reference/register_taxonomy
		 */
		protected function register_taxonomy_category()
		{
			$labels = array(
				'name'                       => __('Categories', 'lagi'),
				'singular_name'              => __('Category', 'lagi'),
				'menu_name'                  => __('Categories', 'lagi'),
				'edit_item'                  => __('Edit Category', 'lagi'),
				'update_item'                => __('Update Category', 'lagi'),
				'add_new_item'               => __('Add New Category', 'lagi'),
				'new_item_name'              => __('New Category Name', 'lagi'),
				'parent_item'                => __('Parent Category', 'lagi'),
				'parent_item_colon'          => __('Parent Category:', 'lagi'),
				'all_items'                  => __('All Categories', 'lagi'),
				'search_items'               => __('Search Categories', 'lagi'),
				'popular_items'              => __('Popular Categories', 'lagi'),
				'separate_items_with_commas' => __('Separate categories with commas', 'lagi'),
				'add_or_remove_items'        => __('Add or remove categories', 'lagi'),
				'choose_from_most_used'      => __('Choose from the most used categories', 'lagi'),
				'not_found'                  => __('No categories found.', 'lagi'),
			);

			$args = array(
				'labels'            => $labels,
				'public'            => true,
				'show_in_nav_menus' => true,
				'show_ui'           => true,
				'show_tagcloud'     => true,
				'hierarchical'      => true,
				'rewrite'           => array('slug' => 'job_category', 'with_front' => false),
				'show_admin_column' => true,
				'query_var'         => true,
				'show_in_rest' 		=> true,
			);

			$args = apply_filters('job_category_args', $args);

			register_taxonomy('job_category', array('job'), $args);

			if (Lagi_Helper::setting('job_page')) {
				add_action('wp_loaded', 'add_job_permastructure');
				function add_job_permastructure()
				{
					$items_link = Lagi_Helper::setting('job_page');
					add_permastruct('job_category',  $items_link . '/%job_category%', false);
					add_permastruct('job', $items_link . '/%job_category%/%job%', false);
				}

				add_filter('post_type_link', 'job_permalinks', 10, 2);
				function job_permalinks($permalink, $post)
				{
					if ($post->post_type !== 'job')
						return $permalink;

					$terms = get_the_terms($post->ID, 'job_category');

					if (!$terms)
						return str_replace('/%job_category%', '', $permalink);

					$post_terms = array();
					foreach ($terms as $term)
						$post_terms[] = $term->slug;

					return str_replace('%job_category%', implode(',', $post_terms), $permalink);
				}

				// Helper function to get all parents of a term
				function get_term_parents($term, &$parents = array())
				{
					$parent = get_term($term->parent, $term->taxonomy);

					if (is_wp_error($parent))
						return $parents;

					$parents[] = $parent;

					if ($parent->parent)
						get_term_parents($parent, $parents);

					return $parents;
				}
			} // Set custom permalinks
		}
	}

	Lagi_job::instance()->initialize();
}
