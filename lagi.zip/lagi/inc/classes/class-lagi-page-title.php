<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Page_Title')) {

    class Lagi_Page_Title
    {

        protected static $instance = null;

        public static function instance()
        {
            if (null === self::$instance) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        public function initialize()
        {
            add_action('init', array($this, 'register_page_title'));
            add_post_type_support('lagi_page_title', 'elementor');
            add_action('lagi_after_header', [$this, 'render']);
        }

        public function render()
        {
            $type = Lagi_Global::instance()->get_page_title_type();
            if ('none' === $type || is_404()) {
                return;
            }

            if ($type === '') {
                get_template_part('templates/page-title/page-title');
            } else {
                if (defined('ELEMENTOR_VERSION') && \Elementor\Plugin::$instance->db->is_built_with_elementor($type)) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content($type);
                } else {
                    $page_title = get_post($type);
                    $page_title_content = $page_title->post_content;
                    echo wp_kses_post($page_title_content);
                }
            }
        }

        /**
         * Register Page Title Post Type
         */
        function register_page_title()
        {
            $labels = array(
                'name' => __('Page Title', 'lagi'),
                'singular_name' => __('Page Title', 'lagi'),
                'add_new' => __('Add New', 'lagi'),
                'add_new_item' => __('Add New', 'lagi'),
                'edit_item' => __('Edit Page Title', 'lagi'),
                'new_item' => __('Add New Page Title', 'lagi'),
                'view_item' => __('View Page Title', 'lagi'),
                'search_items' => __('Search Page Title', 'lagi'),
                'not_found' => __('No items found', 'lagi'),
                'not_found_in_trash' => __('No items found in trash', 'lagi'),
            );

            $args = array(
                'menu_icon' => 'dashicons-buddicons-topics',
                'label' => esc_html__('Page Title', 'lagi'),
                'description' => esc_html__('Page Title', 'lagi'),
                'labels' => $labels,
                'supports' => array(
                    'title',
                    'editor',
                    'revisions',
                ),
                'hierarchical' => false,
                'public' => true,
                'menu_position' => 15,
                'show_in_admin_bar' => true,
                'show_in_nav_menus' => true,
                'can_export' => true,
                'has_archive' => false,
                'exclude_from_search' => true,
                'publicly_queryable' => false,
                'rewrite' => false,
                'capability_type' => 'page',
                'publicly_queryable' => true,
            );
            register_post_type('lagi_page_title', $args);
        }

        public function render_title()
        {
            $title     = '';
            $sub_title     = '';
            $title_tag = 'h1';

            if (get_theme_mod('lagi_portfolio', 0) && Lagi_Portfolio::instance()->is_archive()) {
                $title = Lagi_Helper::setting('page_title_archive_portfolio_title');
            } elseif (is_post_type_archive()) {
                if (function_exists('is_shop') && is_shop()) {
                    $title = esc_html__('Shop', 'lagi');
                } else {
                    $title = sprintf(esc_html__('Archives: %s', 'lagi'), post_type_archive_title('', false));
                }
            } elseif (is_home()) {
                $title = Lagi_Helper::setting('page_title_home_title') . single_tag_title('', false);
            } elseif (is_tag()) {
                $title = Lagi_Helper::setting('page_title_archive_tag_title') . single_tag_title('', false);
            } elseif (is_author()) {
                $title = Lagi_Helper::setting('page_title_archive_author_title') . '<span class="vcard">' . get_the_author() . '</span>';
            } elseif (is_year()) {
                $title = Lagi_Helper::setting('page_title_archive_year_title') . get_the_date(esc_html_x('Y', 'yearly archives date format', 'lagi'));
            } elseif (is_month()) {
                $title = Lagi_Helper::setting('page_title_archive_month_title') . get_the_date(esc_html_x('F Y', 'monthly archives date format', 'lagi'));
            } elseif (is_day()) {
                $title = Lagi_Helper::setting('page_title_archive_day_title') . get_the_date(esc_html_x('F j, Y', 'daily archives date format', 'lagi'));
            } elseif (is_search()) {
                $title = Lagi_Helper::setting('page_title_search_title') . '"' . get_search_query() . '"';
            } elseif (is_category() || is_tax()) {
                $title = Lagi_Helper::setting('page_title_archive_category_title') . single_cat_title('', false);
            } elseif (is_singular()) {
                $title = Lagi_Helper::get_post_meta('page_page_title_custom_heading', '');

                if ('' === $title) {
                    $post_type = get_post_type();
                    switch ($post_type) {
                        case 'post':
                            $title = Lagi_Helper::setting('page_title_single_blog_title');
                            break;
                        case 'portfolio':
                            $title = Lagi_Helper::setting('page_title_single_portfolio_title');
                            break;
                        case 'product':
                            $title = Lagi_Helper::setting('page_title_single_product_title');
                            break;
                    }
                }

                if ('' === $title) {
                    $title = get_the_title();
                } else {
                    $title_tag = 'h2';
                }
                if (class_exists('WooCommerce')) {
                    if (is_cart() || is_checkout()) {
                        $title_tag = 'h2';
                    }
                }
            } else {
                $title = get_the_title();
            }

            if (get_the_title() === 'Shop Left Sidebar' || get_the_title() === 'Shop Right Sidebar') {
                $title_tag = 'h2';
            }

            $sub_title = Lagi_Helper::get_post_meta('page_page_title_custom_sub_heading', '');
?>
            <div class="page-title-heading">
                <?php printf('<%s class="heading heading-font">', $title_tag); ?>
                <?php echo wp_kses($title, array(
                    'span' => [
                        'class' => [],
                    ],
                )); ?>
                <?php printf('</%s>', $title_tag); ?>
                <?php
                if ($sub_title) {
                    echo '<p class="sub-heading">' . esc_html($sub_title) . '</p>';
                }
                ?>
            </div>
<?php
        }
    }

    Lagi_Page_Title::instance()->initialize();
}
