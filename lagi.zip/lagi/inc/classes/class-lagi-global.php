<?php
defined('ABSPATH') || exit;

/**
 * Initialize Global Variables
 */
if (!class_exists('Lagi_Global')) {
	class Lagi_Global
	{

		protected static $instance        = null;
		protected static $page_title_type = '';
		protected static $header_type     = '';
		protected static $header_overlay  = 'no';
		protected static $header_skin     = 'light';
		protected static $header_float    = 'no';
		protected static $footer_type     = '0';

		public static function instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize()
		{
			/**
			 * Use hook wp instead of init because we need post meta setup.
			 * then we must wait for post loaded.
			 */
			add_action('wp', array($this, 'init_global_variable'));

			/**
			 * Setup global variables.
			 * Used priority 12 to wait override settings setup.
			 *
			 * @see Lagi_Customize->setup_override_settings()
			 */
			add_action('wp', array($this, 'setup_global_variables'), 12);
		}

		function init_global_variable()
		{
			global $lagi_page_options;
			if (is_singular('portfolio')) {
				$lagi_page_options = maybe_unserialize(get_post_meta(get_the_ID(), 'lagi_portfolio_options', true));
			} elseif (is_singular('post')) {
				$lagi_page_options = maybe_unserialize(get_post_meta(get_the_ID(), 'lagi_page_options', true));
			} elseif (is_singular('page')) {
				$lagi_page_options = maybe_unserialize(get_post_meta(get_the_ID(), 'lagi_page_options', true));
			} elseif (!is_front_page() && is_home()) {
				$postID = get_queried_object_id();
				$lagi_page_options = maybe_unserialize(get_post_meta($postID, 'lagi_page_options', true));
			} elseif (is_singular('product')) {
				$lagi_page_options = maybe_unserialize(get_post_meta(get_the_ID(), 'lagi_page_options', true));
			}
			if (function_exists('is_shop') && is_shop()) {
				// Get page id of shop.
				$page_id           = wc_get_page_id('shop');
				$lagi_page_options = maybe_unserialize(get_post_meta($page_id, 'lagi_page_options', true));
			}
		}

		public function setup_global_variables()
		{
			$this->set_header_options();
			$this->set_page_title_type();
			$this->set_footer_type();
		}

		public static function get_header_type()
		{
			return self::$header_type;
		}

		public static function get_header_overlay()
		{
			return self::$header_overlay;
		}

		public static function get_header_float()
		{
			return self::$header_float;
		}

		public static function get_header_skin()
		{
			return self::$header_skin;
		}

		public static function get_page_title_type()
		{
			return self::$page_title_type;
		}

		public static function get_footer_type()
		{
			return self::$footer_type;
		}

		public static function get_list_headers($default_option = true)
		{
			$headers = get_posts(array(
				'post_type'      => 'lagi_header',
				'posts_per_page' => -1,
			));

			$arr_header = array('none' => esc_html__('None', 'lagi'));

			if ($default_option === true) {
				$default_text = esc_html__('Default', 'lagi');
				$arr_header   = array('' => $default_text) + $arr_header;
			}

			foreach ($headers as $header) {
				$arr_header[$header->ID] = ucwords($header->post_title);
			}

			return $arr_header;
		}

		public static function get_list_page_titles($default_option = true)
		{
			$page_titles = get_posts(array(
				'post_type'      => 'lagi_page_title',
				'posts_per_page' => -1,
			));

			$arr_page_title = array('none' => esc_html__('None', 'lagi'));

			if ($default_option === true) {
				$default_text = esc_html__('Default', 'lagi');
				$arr_page_title   = array('' => $default_text) + $arr_page_title;
			}

			foreach ($page_titles as $page_title) {
				$arr_page_title[$page_title->ID] = ucwords($page_title->post_title);
			}

			return $arr_page_title;
		}

		public static function get_list_footers($default_option = true)
		{
			$footers = get_posts(array(
				'post_type'      => 'lagi_footer',
				'posts_per_page' => -1,
			));

			$arr_footer = array('0' => __('None', 'lagi'));

			if ($default_option === true) {
				$default_text = esc_html__('Default', 'lagi');
				$arr_footer   = array('' => $default_text) + $arr_footer;
			}

			foreach ($footers as $footer) {
				$arr_footer[$footer->ID] = ucwords($footer->post_title);
			}

			return $arr_footer;
		}


		function set_footer_type()
		{
			$type = Lagi_Helper::get_post_meta('footer_type', '');

			if ($type === '') {
				$type = Lagi_Helper::setting('footer_type');
			}

			self::$footer_type = $type;
		}

		function set_header_options()
		{
			$header_type    = Lagi_Helper::get_post_meta('header_type', '');
			$header_overlay = Lagi_Helper::get_post_meta('header_overlay', '');
			$header_float   = Lagi_Helper::get_post_meta('header_float', '');
			$header_skin    = Lagi_Helper::get_post_meta('header_skin', '');

			if (Lagi_Woo::instance()->is_woocommerce_page_without_product()) {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('product_archive_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('product_archive_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('product_archive_header_float');
				}
			} elseif (Lagi_Portfolio::instance()->is_archive()) {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('portfolio_archive_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('portfolio_archive_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('portfolio_archive_header_float');
				}
			} elseif (Lagi_Post::instance()->is_archive()) {
				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('blog_archive_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('blog_archive_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('blog_archive_header_float');
				}
			} elseif (is_singular('post')) {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('single_post_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('single_post_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('single_post_header_float');
				}
			} elseif (is_singular('portfolio')) {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('portfolio_single_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('portfolio_single_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('portfolio_single_header_float');
				}
			} elseif (is_singular('product')) {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('product_single_header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('product_single_header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('product_single_header_float');
				}
			} else {

				if ($header_type === '') {
					$header_type = Lagi_Helper::setting('header_type');
				}

				if ($header_overlay === '') {
					$header_overlay = Lagi_Helper::setting('header_overlay');
				}

				if ($header_float === '') {
					$header_float = Lagi_Helper::setting('header_float');
				}

				if ($header_skin === '') {
					$header_skin = Lagi_Helper::setting('header_skin');
				}
			}

			if ($header_type === '') {

				$header_type = Lagi_Helper::setting('header_type');
			}

			if ($header_overlay === '') {
				$header_overlay = Lagi_Helper::setting('header_overlay');
			}

			if ($header_float === '') {
				$header_float = Lagi_Helper::setting('header_float');
			}

			if ($header_skin === '') {
				$header_skin = Lagi_Helper::setting('header_skin');
			}

			$header_type    = apply_filters('lagi_header_type', $header_type);
			$header_overlay = apply_filters('lagi_header_overlay', $header_overlay);
			$header_float   = apply_filters('lagi_header_float', $header_float);
			$header_skin    = apply_filters('sala_header_skin', $header_skin);


			self::$header_type    = $header_type;
			self::$header_overlay = $header_overlay;
			self::$header_float   = $header_float;
			self::$header_skin    = $header_skin;
		}

		function set_page_title_type()
		{
			$type = Lagi_Helper::get_post_meta('page_page_title_layout', '');

			if ($type === '') {
				if (Lagi_Woo::instance()->is_woocommerce_page_without_product()) {
					$type = Lagi_Helper::setting('product_archive_page_title_layout');
				} elseif (Lagi_Portfolio::instance()->is_archive()) {
					$type = Lagi_Helper::setting('portfolio_archive_page_title_layout');
				} elseif (Lagi_Post::instance()->is_archive()) {
					$type = Lagi_Helper::setting('blog_archive_page_title_layout');
				} elseif (is_singular('post')) {
					$type = Lagi_Helper::setting('single_post_page_title_layout');
				} elseif (is_singular('page')) {
					$type = Lagi_Helper::setting('page_page_title_layout');
				} elseif (is_singular('product')) {
					$type = Lagi_Helper::setting('single_product_page_title_layout');
				} elseif (is_singular('portfolio')) {
					$type = Lagi_Helper::setting('single_portfolio_page_title_layout');
				} else {
					$type = Lagi_Helper::setting('page_title_layout');
				}

				if ($type === '') {
					$type = Lagi_Helper::setting('page_title_layout');
				}
			}

			$type = apply_filters('lagi_page_title_type', $type);

			self::$page_title_type = $type;
		}

		public static function render_sidebar($position = 'right')
		{
			$classes 		  = array();
			$classes[]        = 'sidebar-' . $position;
			$active_sidebar   = 'blog_sidebar';
			$sidebar_position = 'right';
			if (Lagi_Post::instance()->is_archive()) {
				$sidebar_position = Lagi_Helper::setting('blog_archive_sidebar_position');
				$active_sidebar   = Lagi_Helper::setting('blog_archive_active_sidebar');
				$classes[]        = 'sidebar-blog-archive';
			} elseif (Lagi_Portfolio::instance()->is_archive()) {
				$sidebar_position = Lagi_Helper::setting('portfolio_archive_sidebar_position');
				$active_sidebar   = Lagi_Helper::setting('portfolio_archive_active_sidebar');
				$classes[]        = 'sidebar-portfolio-archive';
			} elseif (Lagi_Woo::instance()->is_product_archive()) {
				$sidebar_position = Lagi_Helper::setting('product_archive_sidebar_position');
				$active_sidebar   = Lagi_Helper::setting('product_archive_active_sidebar');
				$classes[]        = 'sidebar-product-archive';
			} elseif (is_search()) {
				$sidebar_position = Lagi_Helper::setting('blog_archive_sidebar_position');
				$active_sidebar   = Lagi_Helper::setting('blog_archive_active_sidebar');
			} elseif (is_singular()) {
				$post_type = get_post_type();
				// Get values from page options.
				$sidebar_position = Lagi_Helper::get_post_meta('sidebar_position', 'default');
				$active_sidebar   = Lagi_Helper::get_post_meta('active_sidebar', 'default');
				switch ($post_type) {
					case 'post':
						if ($sidebar_position === 'default') {
							$sidebar_position = Lagi_Helper::setting('single_post_sidebar_position');
						}
						if ($active_sidebar === 'default') {
							$active_sidebar = Lagi_Helper::setting('single_post_active_sidebar');
						}
						$classes[] = 'sidebar-single-post';
						break;

					case 'portfolio':
						if ($sidebar_position === 'default') {
							$sidebar_position = Lagi_Helper::setting('single_portfolio_sidebar_position');
						}
						if ($active_sidebar === 'default') {
							$active_sidebar = Lagi_Helper::setting('single_portfolio_active_sidebar');
						}
						$classes[] = 'sidebar-single-portfolio';
						break;

					case 'product':
						if ($sidebar_position === 'default') {
							$sidebar_position = Lagi_Helper::setting('single_product_sidebar_position');
						}
						if ($active_sidebar === 'default') {
							$active_sidebar = Lagi_Helper::setting('single_product_active_sidebar');
						}
						$classes[] = 'sidebar-single-product';
						break;

					case 'lagi_mega_menu':
						$sidebar_position = 'none';
						break;

					default:
						if ($sidebar_position === 'default') {
							$sidebar_position = Lagi_Helper::setting('page_sidebar_position');
						}
						if ($active_sidebar === 'default') {
							$active_sidebar = Lagi_Helper::setting('page_active_sidebar');
						}
						break;
				}
			}

			$sidebar_position = apply_filters('lagi_sidebar_position', $sidebar_position);

			if ($position === $sidebar_position) {
				self::get_sidebar($classes, $active_sidebar);
			}
		}

		public static function get_sidebar($classes, $name)
		{
			if (!is_active_sidebar($name)) {
				return;
			}
?>
			<aside id="secondary" class="<?php echo join(' ', $classes); ?>">
				<div class="inner-sidebar" itemscope="itemscope">
					<?php dynamic_sidebar($name); ?>
				</div>
			</aside>
<?php
		}
	}

	Lagi_Global::instance()->initialize();
}
