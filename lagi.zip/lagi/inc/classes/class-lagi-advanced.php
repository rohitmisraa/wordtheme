<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Advanced')) {
	class Lagi_Advanced
	{

		protected static $instance = null;

		static function instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize()
		{
			add_action('wp_print_styles', array($this, 'deregister_block_styles'), 100);
			add_action('wp_default_scripts', array($this, 'remove_jquery_migrate'));
		}


		function get_md_media_query()
		{
			return '@media (max-width: 1199px)';
		}

		function get_sm_media_query()
		{
			return '@media (max-width: 991px)';
		}

		function get_xs_media_query()
		{
			return '@media (max-width: 767px)';
		}

		function deregister_block_styles()
		{
			$enable = Lagi_Helper::setting('performance_disable_blockcss');
			if (!is_admin() && $enable == true) {
				wp_dequeue_style('wp-block-library');
			}
		}

		function remove_jquery_migrate($scripts)
		{
			$enable = Lagi_Helper::setting('performance_jquery_migrate');
			if ($enable !== true) {
				return;
			}
			if (!is_admin() && isset($scripts->registered['jquery'])) {
				$script = $scripts->registered['jquery'];

				if ($script->deps) {
					$script->deps = array_diff($script->deps, array(
						'jquery-migrate',
					));
				}
			}
		}
	}

	Lagi_Advanced::instance()->initialize();
}
