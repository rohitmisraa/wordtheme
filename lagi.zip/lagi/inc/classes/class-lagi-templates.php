<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('Lagi_Templates')) {

	/**
	 *  Class Lagi_Templates
	 */
	class Lagi_Templates
	{

		/**
		 * The constructor.
		 */
		function __construct()
		{

			// Register shortcode
			add_shortcode('site_logo', array($this, 'site_logo'));
			add_shortcode('main_menu', array($this, 'main_menu'));
			add_shortcode('canvas_menu', array($this, 'canvas_menu'));
			add_shortcode('header_button', array($this, 'header_button'));
			add_shortcode('header_search_icon', array($this, 'header_search_icon'));
			add_shortcode('lagin_form', array($this, 'lagin_form'));
			add_shortcode('register_form', array($this, 'register_form'));
			add_shortcode('forgot_form', array($this, 'forgot_form'));
			add_shortcode('reset_form', array($this, 'reset_form'));
			add_shortcode('scroll_bar', array($this, 'scroll_bar'));

			// Hook Template
			add_action('lagi_before_header', array($this, 'canvas_search'));
		}

		public static function site_logo()
		{

			$logo_dark          = \Lagi_Helper::setting('logo_dark');
			$logo_dark_retina   = \Lagi_Helper::setting('logo_dark_retina');
			$logo_light         = \Lagi_Helper::setting('logo_light');
			$logo_light_retina  = \Lagi_Helper::setting('logo_light_retina');
			$custom_dark_logo   = \Lagi_Helper::get_post_meta('custom_dark_logo', '');
			$custom_light_logo  = \Lagi_Helper::get_post_meta('custom_light_logo', '');
			$header_skin        = \Lagi_Helper::get_post_meta('header_skin', '');

			if ($custom_dark_logo !== '') {
				$logo_dark = $custom_dark_logo;
			}

			if ($custom_light_logo !== '') {
				$logo_light = $custom_light_logo;
			}

			$site_name = get_bloginfo('name', 'display');

			ob_start();

?>
			<div class="site-logo ux-element">
				<?php if (empty($header_skin)) : ?>
					<?php if (!empty($logo_dark) && !empty($logo_light)) : ?>
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr($site_name); ?>">
							<img class="logo-dark" src="<?php echo esc_url($logo_dark); ?>" data-retina="<?php echo esc_attr($logo_dark_retina); ?>" alt="<?php echo esc_attr($site_name); ?>">
							<img class="logo-light" src="<?php echo esc_url($logo_light); ?>" data-retina="<?php echo esc_attr($logo_light_retina); ?>" alt="<?php echo esc_attr($site_name); ?>">
						</a>
					<?php else : ?>
						<?php $blog_info = get_bloginfo('name'); ?>
						<?php if (!empty($blog_info)) : ?>
							<h1 class="site-title"><?php bloginfo('name'); ?></h1>
							<p><?php bloginfo('description'); ?></p>
						<?php endif; ?>
					<?php endif; ?>
				<?php else : ?>
					<?php if ($header_skin == 'light') : ?>
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr($site_name); ?>">
							<img class="logo-light" src="<?php echo esc_url($logo_light); ?>" data-retina="<?php echo esc_attr($logo_light_retina); ?>" alt="<?php echo esc_attr($site_name); ?>">
						</a>
					<?php else : ?>
						<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr($site_name); ?>">
							<img class="logo-dark" src="<?php echo esc_url($logo_dark); ?>" data-retina="<?php echo esc_attr($logo_dark_retina); ?>" alt="<?php echo esc_attr($site_name); ?>">
						</a>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		<?php

			return ob_get_clean();
		}

		public static function main_menu()
		{
			$classes = array('main-menu', 'ux-element', 'site-menu', 'desktop-menu', 'hidden-on-tablet', 'hidden-on-mobile');
			ob_start();
		?>
			<div class="<?php echo join(' ', $classes); ?>" data-id="main-menu">
				<?php
				$args = array();

				$defaults = array(
					'theme_location' => 'main_menu',
					'container'      => 'ul',
					'menu_class'     => 'menu sm sm-simple',
					'extra_class'    => '',
				);

				$args = wp_parse_args($args, $defaults);

				if (has_nav_menu('main_menu') && class_exists('Lagi_Walker_Nav_Menu')) {
					$args['walker'] = new Lagi_Walker_Nav_Menu;
				}

				if (has_nav_menu('main_menu')) {
					wp_nav_menu($args);
				}
				?>
			</div>
		<?php
			return ob_get_clean();
		}

		public static function mobile_menu()
		{
			$user_account             = Lagi_Helper::setting('user_account');
			$url_phone                = Lagi_Helper::setting('url_phone');
			$url_email                = Lagi_Helper::setting('url_email');

			ob_start();
		?>
			<div class="bg-overlay"></div>

			<div class="site-menu area-menu mobile-menu">

				<div class="inner-menu custom-scrollbar">

					<div class="entry-top">
						<a href="#" class="btn-canvas-menu btn-close"><i class="fal fa-times"></i></a>

						<?php
						if (has_nav_menu('mobile_menu')) {
							$theme_location = 'mobile_menu';
						} else {
							$theme_location = 'main_menu';
						}

						$args = array(
							'menu_class'     => 'menu',
							'container'      => '',
							'theme_location' => $theme_location,
						);

						if (has_nav_menu('main_menu') && class_exists('Lagi_Walker_Nav_Menu')) {
							$args['walker'] = new Lagi_Walker_Nav_Menu;
						}

						wp_nav_menu($args);
						?>
					</div>

					<div class="entry-bottom">
						<?php if (!empty($user_account)) : ?>
							<?php
							$signin = get_the_permalink(Lagi_Helper::setting('setup_page_sign_in'));
							if (is_user_logged_in()) :
								$current_user = wp_get_current_user();
							?>
								<a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>" class="user-account logged">
									<?php echo get_avatar(get_the_author_meta('ID'), 32); ?>
									<?php echo esc_html($current_user->display_name); ?>
								</a>
							<?php
							else :
							?>
								<a href="<?php echo esc_url($signin); ?>" class="user-account unlog">
									<i class="fas fa-user-circle"></i>
									<?php echo esc_html('Log In', 'lagi'); ?>
								</a>
							<?php
							endif;
							?>
						<?php endif; ?>
						<?php if (!empty($url_phone)) : ?>
							<a href="tel:<?php echo esc_attr($url_phone); ?>"><?php echo sprintf(esc_html__('Call. %s', 'lagi'), $url_phone); ?></a>
						<?php endif; ?>
						<?php if (!empty($url_email)) : ?>
							<a href="mailto:<?php echo esc_attr($url_email); ?>"><?php echo sprintf(esc_html__('Email. %s', 'lagi'), $url_email); ?></a>
						<?php endif; ?>
						<div class="social-links">
							<?php
							$tooltip = array(
								'style'            => 'icons',
								'target'           => '_blank',
								'tooltip_enable'   => true,
								'tooltip_skin'     => 'primary',
								'tooltip_position' => 'top',
							);
							$canvas_menu_social_enable = Lagi_Helper::setting('canvas_menu_social_enable', '1');
							if (!empty($canvas_menu_social_enable)) {
								$canvas_menu_social_order = Lagi_Helper::setting('canvas_menu_social_order');
								$link_classes = '';

								if ($tooltip['tooltip_enable'] === true) {
									$link_classes .= "hint--bounce hint--{$tooltip['tooltip_position']} hint--{$tooltip['tooltip_skin']}";
								}

								if (!empty($canvas_menu_social_order)) {
									foreach ($canvas_menu_social_order as $social) {
										if (is_array($canvas_menu_social_enable) &&  in_array($social, $canvas_menu_social_enable, true)) {
											$url_facebook    = Lagi_Helper::setting('url_facebook');
											$url_twitter     = Lagi_Helper::setting('url_twitter');
											$url_instagram   = Lagi_Helper::setting('url_instagram');
											$url_linkedin    = Lagi_Helper::setting('url_linkedin');
											$url_tripadvisor = Lagi_Helper::setting('url_tripadvisor');

											if ($social === 'facebook' && !empty($url_facebook)) {
							?>
												<a class="<?php echo esc_attr($link_classes . ' facebook'); ?>" target="<?php echo esc_attr($tooltip['target']); ?>" aria-label="<?php esc_attr_e('Facebook', 'lagi'); ?>" href="<?php echo esc_url($url_facebook); ?>">
													<?php if ($tooltip['style'] === 'text') : ?>
														<span><?php esc_html_e('Facebook', 'lagi'); ?></span>
													<?php else : ?>
														<i class="fab fa-facebook-f"></i>
													<?php endif; ?>
												</a>
											<?php
											} elseif ($social === 'twitter' && !empty($url_twitter)) {
											?>
												<a class="<?php echo esc_attr($link_classes . ' twitter'); ?>" target="<?php echo esc_attr($tooltip['target']); ?>" aria-label="<?php esc_attr_e('Twitter', 'lagi'); ?>" href="<?php echo esc_url($url_twitter); ?>">
													<?php if ($tooltip['style'] === 'text') : ?>
														<span><?php esc_html_e('Twitter', 'lagi'); ?></span>
													<?php else : ?>
														<i class="fab fa-twitter"></i>
													<?php endif; ?>
												</a>
											<?php
											} elseif ($social === 'instagram' && !empty($url_instagram)) {
											?>
												<a class="<?php echo esc_attr($link_classes . ' instagram'); ?>" target="<?php echo esc_attr($tooltip['target']); ?>" aria-label="<?php esc_attr_e('Instagram', 'lagi'); ?>" href="<?php echo esc_url($url_twitter); ?>">
													<?php if ($tooltip['style'] === 'text') : ?>
														<span><?php esc_html_e('Instagram', 'lagi'); ?></span>
													<?php else : ?>
														<i class="fab fa-instagram"></i>
													<?php endif; ?>
												</a>
											<?php
											} elseif ($social === 'linkedin' && !empty($url_linkedin)) {
											?>
												<a class="<?php echo esc_attr($link_classes . ' linkedin'); ?>" target="<?php echo esc_attr($tooltip['target']); ?>" aria-label="<?php esc_attr_e('Linkedin', 'lagi'); ?>" href="<?php echo esc_url($url_linkedin); ?>">
													<?php if ($tooltip['style'] === 'text') : ?>
														<span><?php esc_html_e('Linkedin', 'lagi'); ?></span>
													<?php else : ?>
														<i class="fab fa-linkedin"></i>
													<?php endif; ?>
												</a>
											<?php
											} elseif ($social === 'tripadvisor' && !empty($url_tripadvisor)) {
											?>
												<a class="<?php echo esc_attr($link_classes . ' tripadvisor'); ?>" target="<?php echo esc_attr($tooltip['target']); ?>" aria-label="<?php esc_attr_e('Tripadvisor', 'lagi'); ?>" href="<?php echo esc_url($url_tripadvisor); ?>">
													<?php if ($tooltip['style'] === 'text') : ?>
														<span><?php esc_html_e('Tripadvisor', 'lagi'); ?></span>
													<?php else : ?>
														<i class="fab fa-tripadvisor"></i>
													<?php endif; ?>
												</a>
							<?php
											}
										}
									}
								}
							}
							?>
						</div>
					</div>
				</div>
			</div>
		<?php
			return ob_get_clean();
		}

		public static function canvas_menu()
		{
			ob_start();
		?>
			<div class="canvas-menu ux-element mb-menu canvas-left hidden-on-desktop">
				<a href="#" class="icon-menu">
					<svg width="30px" height="14px" viewBox="0 0 30 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
						<g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
							<g transform="translate(-50.000000, -33.000000)" fill="#111111">
								<g id="off-menu" transform="translate(50.000000, 28.000000)">
									<g id="icon-menu" transform="translate(0.000000, 5.000000)">
										<rect id="Rectangle-1" x="0" y="0" width="30" height="3" rx="1.5"></rect>
										<rect id="Rectangle-2" x="0" y="11" width="20" height="3" rx="1.5"></rect>
									</g>
								</g>
							</g>
						</g>
					</svg>
				</a>
				<?php echo self::mobile_menu(); ?>
			</div>
		<?php
			return ob_get_clean();
		}

		public static function header_button()
		{
			$header_button       = Lagi_Helper::setting('header_button');
			$header_link_button  = Lagi_Helper::setting('header_link_button');
			if ($header_button !== true) {
				return;
			}

			if ($header_link_button == '') {
				$link_button = '#';
			} else {
				$link_button = get_permalink($header_link_button);
			}

			ob_start();
		?>
			<div class="header-button">
				<a href="<?php echo $link_button; ?>" class="lagi-btn btn-round">
					<?php echo esc_html__('Let’s Talk', 'lagi'); ?>
				</a>
			</div>

		<?php
			return ob_get_clean();
		}

		public static function header_search_icon()
		{
			$header_search_icon = Lagi_Helper::setting('header_search_icon');
			if ($header_search_icon !== true) {
				return;
			}

			ob_start();
		?>
			<div class="icon-search">
				<a href="#canvas-search" class="btn-lagi-popup"><i class="far fa-search large"></i></a>
			</div>
		<?php
			return ob_get_clean();
		}

		public static function canvas_search()
		{

		?>
			<div id="canvas-search" class="lagi-popup popup-search">
				<div class="bg-overlay"></div>
				<a href="#" class="btn-canvas-menu btn-close"><i class="fal fa-times"></i></a>
				<div class="inner-popup">
					<?php echo self::search_form(); ?>
				</div>
			</div>
		<?php
		}

		public static function search_form()
		{

			$ajax_search = true;

			$classes = array('search-form');

			if ($ajax_search) {
				$classes[] = 'ajax-search-form';
			}

			$post_type    = 'post';
			$place_holder = esc_html__('Search...', 'lagi');

			ob_start();
		?>
			<div class="<?php echo join(' ', $classes); ?>">
				<form action="<?php echo esc_url(home_url('/')); ?>" method="get" class="search-form">
					<div class="area-search form-field">
						<button type="submit" class="search-btn-icon"><i class="far fa-search large"></i></button>
						<div class="form-field input-field">
							<input name="s" class="input-search" type="text" value="<?php echo get_search_query(); ?>" placeholder="<?php echo esc_attr($place_holder); ?>" autocomplete="off" />
							<input type="hidden" name="post_type" class="post-type" value="<?php echo esc_attr($post_type); ?>" />
							<div class="search-result area-result"></div>
							<div class="lagi-loading-effect"><span class="lagi-dual-ring"></span></div>

							<?php
							$place_categories = get_categories(array(
								'taxonomy'   => 'categories',
								'hide_empty' => 1,
								'orderby'    => 'term_id',
								'order'      => 'ASC'
							));
							?>
							<?php if ($place_categories) : ?>
								<div class="list-categories">
									<ul>
										<?php
										$image_src = SALA_THEME_DIR . 'assets/images/no-image.jpg';
										foreach ($place_categories as $cate) {
											$cate_id   = $cate->term_id;
											$cate_name = $cate->name;
											$cate_slug = $cate->slug;
										?>
											<li>
												<a class="entry-category" href="<?php echo get_term_link($cate); ?>">
													<span><?php echo esc_html($cate_name); ?></span>
												</a>
											</li>
										<?php } ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</form>
			</div>
		<?php
			return ob_get_clean();
		}

		/**
		 * Render Comments
		 */
		public static function render_comments($comment, $args, $depth)
		{
			Lagi_Helper::lagi_get_template('comment', array('comment' => $comment, 'args' => $args, 'depth' => $depth));
		}

		public static function render_button($args)
		{
			$defaults = [
				'text'          => '',
				'link'          => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
				'style'         => 'flat',
				'size'          => 'sm',
				'icon'          => '',
				'icon_align'    => 'left',
				'extra_class'   => '',
				'class'         => 'lagi-button',
				'id'            => '',
				'wrapper_class' => '',
			];

			$args = wp_parse_args($args, $defaults);
			extract($args);

			$button_attrs = [];

			$button_classes   = [$class];
			$button_classes[] = $style;
			$button_classes[] = 'size-' . $size;

			if (!empty($extra_class)) {
				$button_classes[] = $extra_class;
			}

			if (!empty($icon)) {
				$button_classes[] = 'icon-' . $icon_align;
			}

			$button_attrs['class'] = implode(' ', $button_classes);

			if (!empty($id)) {
				$button_attrs['id'] = $id;
			}

			$button_tag = 'div';

			if (!empty($link['url'])) {
				$button_tag = 'a';

				$button_attrs['href'] = $link['url'];

				if (!empty($link['is_external'])) {
					$button_attrs['target'] = '_blank';
				}

				if (!empty($link['nofollow'])) {
					$button_attrs['rel'] = 'nofollow';
				}
			}

			$attributes_str = '';

			if (!empty($button_attrs)) {
				foreach ($button_attrs as $attribute => $value) {
					$attributes_str .= ' ' . $attribute . '="' . esc_attr($value) . '"';
				}
			}

			$wrapper_classes = 'lagi-button-wrapper';
			if (!empty($wrapper_class)) {
				$wrapper_classes .= " $wrapper_class";
			}
		?>
			<div class="<?php echo esc_attr($wrapper_classes); ?>">
				<?php printf('<%1$s %2$s>', $button_tag, $attributes_str); ?>
				<div class="button-content-wrapper">

					<?php if (!empty($icon) && 'left' === $icon_align) : ?>
						<span class="button-icon"><i class="<?php echo esc_attr($icon); ?>"></i></span>
					<?php endif; ?>

					<?php if (!empty($text)) : ?>
						<span class="button-text"><?php echo esc_html($text); ?></span>
					<?php endif; ?>

					<?php if (!empty($icon) && 'right' === $icon_align) : ?>
						<span class="button-icon"><i class="<?php echo esc_attr($icon); ?>"></i></span>
					<?php endif; ?>
				</div>
				<?php printf('</%1$s>', $button_tag); ?>
			</div>
			<?php
		}

		public static function  get_sharing_list($args = array())
		{
			$defaults = array(
				'style'            => 'icons',
				'target'           => '_blank',
				'tooltip_enable'   => true,
				'tooltip_skin'     => 'primary',
				'tooltip_position' => 'top',
			);
			$args = wp_parse_args($args, $defaults);
			$social_sharing_item_enable = Lagi_Helper::setting('social_sharing_item_enable', '1');
			if (!empty($social_sharing_item_enable)) {
				$social_sharing_order = Lagi_Helper::setting('social_sharing_order');
				$link_classes = '';

				if ($args['tooltip_enable'] === true) {
					$link_classes .= "hint--bounce hint--{$args['tooltip_position']} hint--{$args['tooltip_skin']}";
				}

				foreach ($social_sharing_order as $social) {
					if (in_array($social, $social_sharing_item_enable, true)) {
						if ($social === 'facebook') {
							$facebook_url = 'https://m.facebook.com/sharer.php?u=' . rawurlencode(get_permalink());
			?>
							<a class="<?php echo esc_attr($link_classes . ' facebook'); ?>" target="<?php echo esc_attr($args['target']); ?>" aria-label="<?php esc_attr_e('Facebook', 'lagi'); ?>" href="<?php echo esc_url($facebook_url); ?>">
								<?php if ($args['style'] === 'text') : ?>
									<span><?php esc_html_e('Facebook', 'lagi'); ?></span>
								<?php else : ?>
									<i class="fab fa-facebook-f"></i>
								<?php endif; ?>
							</a>
						<?php
						} elseif ($social === 'twitter') {
						?>
							<a class="<?php echo esc_attr($link_classes . ' twitter'); ?>" target="<?php echo esc_attr($args['target']); ?>" aria-label="<?php esc_attr_e('Twitter', 'lagi'); ?>" href="https://twitter.com/share?text=<?php echo rawurlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')); ?>&url=<?php echo rawurlencode(get_permalink()); ?>">
								<?php if ($args['style'] === 'text') : ?>
									<span><?php esc_html_e('Twitter', 'lagi'); ?></span>
								<?php else : ?>
									<i class="fab fa-twitter"></i>
								<?php endif; ?>
							</a>
						<?php
						} elseif ($social === 'tumblr') {
						?>
							<a class="<?php echo esc_attr($link_classes . ' tumblr'); ?>" target="<?php echo esc_attr($args['target']); ?>" aria-label="<?php esc_attr_e('Tumblr', 'lagi'); ?>" href="https://www.tumblr.com/share/link?url=<?php echo rawurlencode(get_permalink()); ?>&amp;name=<?php echo rawurlencode(get_the_title()); ?>">
								<?php if ($args['style'] === 'text') : ?>
									<span><?php esc_html_e('Tumblr', 'lagi'); ?></span>
								<?php else : ?>
									<i class="fab fa-tumblr-square"></i>
								<?php endif; ?>
							</a>
						<?php
						} elseif ($social === 'linkedin') {
						?>
							<a class="<?php echo esc_attr($link_classes . ' linkedin'); ?>" target="<?php echo esc_attr($args['target']); ?>" aria-label="<?php esc_attr_e('Linkedin', 'lagi'); ?>" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo rawurlencode(get_permalink()); ?>&amp;title=<?php echo rawurlencode(get_the_title()); ?>">
								<?php if ($args['style'] === 'text') : ?>
									<span><?php esc_html_e('Linkedin', 'lagi'); ?></span>
								<?php else : ?>
									<i class="fab fa-linkedin"></i>
								<?php endif; ?>
							</a>
						<?php
						} elseif ($social === 'email') {
						?>
							<a class="<?php echo esc_attr($link_classes . ' email'); ?>" target="<?php echo esc_attr($args['target']); ?>" aria-label="<?php esc_attr_e('Email', 'lagi'); ?>" href="mailto:?subject=<?php echo rawurlencode(get_the_title()); ?>&amp;body=<?php echo rawurlencode(get_permalink()); ?>">
								<?php if ($args['style'] === 'text') : ?>
									<span><?php esc_html_e('Email', 'lagi'); ?></span>
								<?php else : ?>
									<i class="fas fa-envelope"></i>
								<?php endif; ?>
							</a>
				<?php
						}
					}
				}
			}
		}

		/**
		 * Display navigation to next/previous set of posts when applicable.
		 */
		public static function pagination($pagination_position = 'center', $pagination_type = 'infinite')
		{

			global $wp_query, $wp_rewrite;

			// Don't print empty markup if there's only one page.
			if ($wp_query->max_num_pages < 2) {
				return;
			}

			$layout = '';
			if (Lagi_Post::instance()->is_archive()) {
				$layout              = Lagi_Helper::setting('blog_archive_post_layout');
				$pagination_position = Lagi_Helper::setting('blog_archive_pagination_position');
				$pagination_type     = Lagi_Helper::setting('blog_archive_pagination_type');
			} elseif (class_exists('Lagi_Portfolio') && Lagi_Portfolio::instance()->is_archive()) {
				$layout              = Lagi_Helper::setting('portfolio_archive_post_layout');
				$pagination_position = Lagi_Helper::setting('portfolio_archive_pagination_position');
				$pagination_type     = Lagi_Helper::setting('portfolio_archive_pagination_type');
			} elseif (Lagi_Woo::instance()->is_product_archive()) {
				$layout              = Lagi_Helper::setting('product_archive_layout');
				$pagination_position = Lagi_Helper::setting('product_archive_pagination_position');
				$pagination_type     = Lagi_Helper::setting('product_archive_pagination_type');
			}

			$paged        = get_query_var('paged') ? intval(get_query_var('paged')) : 1;
			$pagenum_link = wp_kses(get_pagenum_link(), Lagi_Helper::lagi_kses_allowed_html());
			$query_args   = array();
			$url_parts    = explode('?', $pagenum_link);

			if (isset($url_parts[1])) {
				wp_parse_str($url_parts[1], $query_args);
			}

			$pagenum_link = esc_url(remove_query_arg(array_keys($query_args), $pagenum_link));
			$pagenum_link = trailingslashit($pagenum_link) . '%_%';

			$format = $wp_rewrite->using_index_permalinks() && !strpos(
				$pagenum_link,
				'index.php'
			) ? 'index.php/' : '';
			$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit(
				$wp_rewrite->pagination_base . '/%#%',
				'paged'
			) : '?paged=%#%';

			// Set up paginated links.
			$links = paginate_links(array(
				'format'    => $format,
				'total'     => $wp_query->max_num_pages,
				'current'   => $paged,
				'add_args'  => array_map('urlencode', $query_args),
				'prev_text' => '<i class="far fa-angle-left"></i>',
				'next_text' => '<i class="far fa-angle-right"></i>',
				'type'      => 'list',
				'end_size'  => 1,
				'mid_size'  => 1,
			));
			$pagination_classes = array('lagi-pagination', $pagination_position, $pagination_type);

			if ($links) {
				$post_type  = get_post_type();
				$query_vars = $wp_query->query_vars;

				$query_vars['post_status'] = array('publish', 'private');
				$query_vars['paged']       = $paged;

				$lagi_grid_query['action']        = "{$post_type}_infinite_load";
				$lagi_grid_query['max_num_pages'] = $wp_query->max_num_pages;
				$lagi_grid_query['found_posts']   = $wp_query->found_posts;
				$lagi_grid_query['pagination_type'] = $pagination_type;
				$lagi_grid_query['layout']  	  = $layout;
				$lagi_grid_query['query_vars']    = $query_vars;
				$lagi_grid_query				  = htmlspecialchars(wp_json_encode($lagi_grid_query));
				?>

				<input type="hidden" class="lagi-query-input" <?php echo 'value="' . $lagi_grid_query . '"'; ?> />

				<?php
				switch ($pagination_type) {
					case 'navigation':
				?>
						<div class="<?php echo join(' ', $pagination_classes); ?>">
							<?php echo wp_kses($links, Lagi_Helper::lagi_kses_allowed_html()); ?>
						</div><!-- .pagination -->
					<?php
						break;

					case 'loadmore':
					?>
						<div class="<?php echo join(' ', $pagination_classes); ?>">
							<a class="lagi-loadmore-button lagi-button border-line uppercase" href="#">
								<i class="fal fa-redo"></i>
								<?php esc_html_e('Load More', 'lagi'); ?>
							</a>
							<div class="lagi-loader">
								<div class="dot-spin"></div>
							</div>
						</div><!-- .pagination -->
						<div class="lagi-pagination-messages">
							<?php esc_html_e('End of Content', 'lagi'); ?>
						</div>
					<?php
						break;

					case 'infinite':
					?>
						<div class="<?php echo join(' ', $pagination_classes); ?>">
							<div class="lagi-loader">
								<div class="dot-falling"></div>
							</div>
						</div><!-- .pagination -->
						<div class="lagi-pagination-messages">
							<?php esc_html_e('End of Content', 'lagi'); ?>
						</div>
			<?php
						break;

					default:

						break;
				}
			}
		}

		public static function lagin_form()
		{
			ob_start();
			?>
			<form action="#" id="lagi-lagin" class="form-account active" method="post">
				<div class="form-group">
					<label for="ip_email" class="label-field"><?php esc_html_e('Email*', 'lagi'); ?></label>
					<input type="text" id="ip_email" class="form-control input-field" name="email">
				</div>
				<?php
				$forgot_password = Lagi_Helper::setting('setup_page_forgot_password');
				?>
				<div class="form-group">
					<label for="ip_password" class="label-field"><?php esc_html_e('Password*', 'lagi'); ?><a class="btn-reset-password" href="<?php echo get_permalink($forgot_password); ?>"><?php esc_html_e('Forgot password?', 'lagi'); ?></a></label>
					<div class="password-input"><input type="password" id="ip_password" class="form-control input-field" name="password"></div>
				</div>
				<div class="form-group">
					<label class="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="yes"><span><?php esc_html_e('Remember Me', 'lagi'); ?></span></label>
				</div>

				<p class="msg"><?php esc_html_e('Sending lagin info,please wait...', 'lagi'); ?></p>

				<div class="form-group">
					<button type="submit" class="gl-button btn button" value="<?php esc_attr_e('Sign in', 'lagi'); ?>"><?php esc_html_e('Sign in', 'lagi'); ?></button>
					<div class="loading-effect"><span class="lagi-dual-ring"></span></div>
				</div>
			</form>
		<?php
			return ob_get_clean();
		}

		public static function register_form()
		{
			ob_start();
		?>
			<form action="#" id="lagi-register" class="form-account" method="post">
				<div class="form-group">
					<label for="ip_reg_firstname" class="label-field"><?php esc_html_e('First Name*', 'lagi'); ?></label>
					<input type="text" id="ip_reg_firstname" placeholder="<?php esc_attr_e('ex: Kevin', 'lagi'); ?>" class="form-control input-field" name="reg_firstname">
				</div>
				<div class="form-group">
					<label for="ip_reg_lastname" class="label-field"><?php esc_html_e('Last Name*', 'lagi'); ?></label>
					<input type="text" id="ip_reg_lastname" placeholder="<?php esc_attr_e('ex: Kay', 'lagi'); ?>" class="form-control input-field" name="reg_lastname">
				</div>
				<div class="form-group">
					<label for="ip_reg_email" class="label-field"><?php esc_html_e('Email*', 'lagi'); ?></label>
					<input type="email" id="ip_reg_email" placeholder="<?php esc_attr_e('ex: kevin@uxper.co', 'lagi'); ?>" class="form-control input-field" name="reg_email">
				</div>
				<div class="form-group">
					<label for="ip_reg_password" class="label-field"><?php esc_html_e('Password*', 'lagi'); ?></label>
					<div class="password-input"><input type="password" id="ip_reg_password" placeholder="<?php esc_attr_e('********', 'lagi'); ?>" class="form-control input-field" name="reg_password"></div>
				</div>
				<div class="form-group accept-account">
					<?php
					$terms 				= Lagi_Helper::setting('setup_page_terms');
					$privacy_policy 	= Lagi_Helper::setting('setup_page_privacy_policy');
					?>
					<label for="ip_accept_account"><input type="checkbox" id="ip_accept_account" class="form-control custom-checkbox" name="accept_account"><span><?php printf(esc_html__('I agree to the %1$s and %2$s', 'lagi'), '<a href="' . get_permalink($terms) . '" target="_Blank">' . esc_html__('Terms', 'lagi') . '</a>', '<a href="' . get_permalink($privacy_policy) . '" target="_Blank">' . esc_html__('Privacy Policy', 'lagi') . '</a></span>'); ?></label>
				</div>

				<p class="msg"><?php esc_html_e('Sending register info,please wait...', 'lagi'); ?></p>

				<div class="form-group">
					<button type="submit" class="gl-button btn button" value="<?php esc_attr_e('Sign in', 'lagi'); ?>"><?php esc_html_e('Sign up', 'lagi'); ?></button>
				</div>
			</form>
		<?php
			return ob_get_clean();
		}

		public static function forgot_form()
		{
			ob_start();
		?>
			<form method="post" id="forgot-form" class="forgot-form" enctype="multipart/form-data">
				<div class="form-group control-username">
					<input type="text" name="user_lagin" id="user_lagin" class="form-control control-icon" placeholder="<?php esc_attr_e('Enter your username or email', 'lagi'); ?>">
					<?php wp_nonce_field('lagi_reset_password_ajax_nonce', 'lagi_security_reset_password'); ?>
					<input type="hidden" name="action" id="reset_password_action" value="lagi_reset_password_ajax">
				</div>
				<p class="msg"><?php esc_html_e('Sending info,please wait...', 'lagi'); ?></p>
				<div class="form-group">
					<button type="submit" id="lagi_forgetpass" class="btn gl-button"><?php esc_html_e('Get new password', 'lagi'); ?></button>
					<div class="loading-effect"><span class="lagi-dual-ring"></span></div>
				</div>
			</form>
		<?php
			return ob_get_clean();
		}

		public static function reset_form()
		{
			ob_start();
		?>
			<form action="#" method="post" id="reset-form" class="reset-form">
				<div class="form-group control-password">
					<div class="password-input"><input name="new_password" type="password" id="new-password" class="form-control control-icon" placeholder="<?php esc_attr_e('Enter new password', 'lagi'); ?>"></div>
				</div>
				<p class="msg"><?php esc_html_e('Sending info,please wait...', 'lagi'); ?></p>
				<div class="button-wrap">
					<a href="#" class="generate-password"><?php esc_html_e('Generate Password', 'lagi'); ?></a>
					<button type="submit" id="lagi_newpass" class="btn gl-button"><?php esc_html_e('Save password', 'lagi'); ?></button>
					<input type="hidden" name="lagin" id="lagin" value="<?php echo $_GET['lagin']; ?>">
				</div>
			</form>
		<?php
			return ob_get_clean();
		}

		public static function scroll_bar()
		{
			ob_start();
		?>
			<div class="scroll-bar-wrap">
				<div class="scroll-bar-current"></div>
			</div>
<?php
			return ob_get_clean();
		}
	}

	new Lagi_Templates();
}
