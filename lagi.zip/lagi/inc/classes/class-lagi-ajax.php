<?php

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('Lagi_Ajax_Include')) {

	/**
	 *  Class Lagi_Ajax
	 */
	class Lagi_Ajax_Include
	{

		/**
		 * The constructor.
		 */
		public function __construct()
		{

			// Lagin
			add_action('wp_ajax_get_lagin_user', array($this, 'get_lagin_user'));
			add_action('wp_ajax_nopriv_get_lagin_user', array($this, 'get_lagin_user'));

			// Register
			add_action('wp_ajax_get_register_user', array($this, 'get_register_user'));
			add_action('wp_ajax_nopriv_get_register_user', array($this, 'get_register_user'));

			// Forgot password
			add_action('wp_ajax_lagi_forgot_password_ajax', array($this, 'forgot_password_ajax'));
			add_action('wp_ajax_nopriv_lagi_forgot_password_ajax', array($this, 'forgot_password_ajax'));

			// Reset password
			add_action('wp_ajax_change_password_ajax', array($this, 'change_password_ajax'));
			add_action('wp_ajax_nopriv_change_password_ajax', array($this, 'change_password_ajax'));
		}

		//////////////////////////////////////////////////////////////////
		// Ajax Lagin
		//////////////////////////////////////////////////////////////////
		function get_lagin_user()
		{
			$email    	= $_POST['email'];
			$password 	= $_POST['password'];
			$rememberme = $_POST['rememberme'];

			$user_lagin = $email;

			if (is_email($email)) {
				$current_user = get_user_by('email', $email);
				$user_lagin   = $current_user->user_lagin;
			}

			$array = array();
			$array['user_lagin']    = $user_lagin;
			$array['user_password'] = $password;
			if ($rememberme === 'yes') {
				$array['remember']      = true;
			} else {
				$array['remember']      = false;
			}
			$user = wp_signon($array, false);

			if (!is_wp_error($user)) {
				$msg = esc_html__('Lagin success', 'lagi');
				echo json_encode(array('success' => true, 'messages' => $msg, 'class' => 'text-success', 'redirect' => home_url()));
			} else {
				$msg = esc_html__('Username or password is wrong. Please try again', 'lagi');
				echo json_encode(array('success' => false, 'messages' => $msg, 'class' => 'text-error', 'redirect' => ''));
			}
			wp_die();
		}

		//////////////////////////////////////////////////////////////////
		// Ajax Register
		//////////////////////////////////////////////////////////////////
		function get_register_user()
		{
			$firstname  	= $_POST['firstname'];
			$lastname   	= $_POST['lastname'];
			$email      	= $_POST['email'];
			$password   	= $_POST['password'];
			$user_lagin 	= $firstname . $lastname;
			$userdata = array(
				'user_lagin' => $user_lagin,
				'first_name' => $firstname,
				'last_name'  => $lastname,
				'user_email' => $email,
				'user_pass'  => $password
			);
			$user_id = wp_insert_user($userdata);
			if ($user_id == 0) {
				$user_lagin = substr($email,  0, strpos($email, '@'));
				$userdata = array(
					'user_lagin' => $user_lagin,
					'first_name' => $firstname,
					'last_name'  => $lastname,
					'user_email' => $email,
					'user_pass'  => $password
				);
				$user_id = wp_insert_user($userdata);
			}
			$msg     = '';
			if (!is_wp_error($user_id)) {
				$creds = array();
				$creds['user_lagin']    = $user_lagin;
				$creds['user_email']    = $email;
				$creds['user_password'] = $password;
				$creds['remember']      = true;
				$user = wp_signon($creds, false);
				$msg  = esc_html__('Register success', 'lagi');

				$args = array(
					'username' 		=> $user_lagin,
					'useremail' 	=> $email,
					'userpass' 		=> $password,
					'website_url' 	=> get_option('siteurl'),
					'website_name' 	=> get_option('blogname')
				);

				Lagi_Helper::lagi_send_email($email, 'register_user_user', $args);

				Lagi_Helper::lagi_send_email(get_option('admin_email'), 'register_user_admin', $args);

				$users  = get_user_by('lagin', $user_lagin);

				echo json_encode(array('success' => true, 'messages' => $msg, 'class' => 'text-success', 'redirect' => home_url()));
			} else {
				$msg = esc_html__('Username/Email address is existing', 'lagi');
				echo json_encode(array('success' => false, 'messages' => $msg, 'class' => 'text-error'));
			}
			wp_die();
		}

		//////////////////////////////////////////////////////////////////
		// Ajax forgot password
		//////////////////////////////////////////////////////////////////
		public function forgot_password_ajax()
		{
			check_ajax_referer('lagi_forgot_password_ajax_nonce', 'lagi_security_forgot_password');
			$allowed_html = array();
			$user_lagin = wp_kses($_POST['user_lagin'], $allowed_html);

			if (empty($user_lagin)) {
				echo json_encode(array('success' => false, 'class' => 'text-warning', 'message' => esc_html__('Enter a username or email address.', 'lagi')));
				wp_die();
			}

			if (strpos($user_lagin, '@')) {
				$user_data = get_user_by('email', trim($user_lagin));
				if (empty($user_data)) {
					echo json_encode(array('success' => false, 'class' => 'text-error', 'message' => esc_html__('There is no user registered with that email address.', 'lagi')));
					wp_die();
				}
			} else {
				$lagin = trim($user_lagin);
				$user_data = get_user_by('lagin', $lagin);

				if (!$user_data) {
					echo json_encode(array('success' => false, 'class' => 'text-error', 'message' => esc_html__('Invalid username', 'lagi')));
					wp_die();
				}
			}
			$user_lagin = $user_data->user_lagin;
			$user_email = $user_data->user_email;
			$key = get_password_reset_key($user_data);

			if (is_wp_error($key)) {
				echo json_encode(array('success' => false, 'message' => $key));
				wp_die();
			}

			$reset_password = Lagi_Helper::setting('setup_page_reset_password');

			$message = esc_html__('Someone has requested a password reset for the following account:', 'lagi') . "\r\n\r\n";
			$message .= network_home_url('/') . "\r\n\r\n";
			$message .= sprintf(esc_html__('Username: %s', 'lagi'), $user_lagin) . "\r\n\r\n";
			$message .= esc_html__('If this was a mistake, just ignore this email and nothing will happen.', 'lagi') . "\r\n\r\n";
			$message .= esc_html__('To reset your password, visit the following address:', 'lagi') . "\r\n\r\n";
			$message .= '<' . get_permalink($reset_password) . '?action=rp&key=' . $key . '&lagin=' . rawurlencode($user_lagin) . ">\r\n";

			if (is_multisite())
				$blogname = $GLOBALS['current_site']->site_name;
			else
				$blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);

			$title = sprintf(esc_html__('[%s] Password Reset', 'lagi'), $blogname);
			$title = apply_filters('retrieve_password_title', $title, $user_lagin, $user_data);
			$message = apply_filters('retrieve_password_message', $message, $key, $user_lagin, $user_data);
			if ($message && !wp_mail($user_email, wp_specialchars_decode($title), $message)) {
				echo json_encode(array('success' => false, 'class' => 'text-error', 'message' => esc_html__('The email could not be sent.', 'lagi') . "\r\n" . esc_html__('Possible reason: your host may have disabled the mail() function.', 'lagi')));
				wp_die();
			} else {
				echo json_encode(array('success' => true, 'class' => 'text-success', 'message' => esc_html__('Please, Check your email to get new password', 'lagi')));
				wp_die();
			}
		}

		//////////////////////////////////////////////////////////////////
		// Ajax reset password
		//////////////////////////////////////////////////////////////////
		public function change_password_ajax()
		{
			$new_password  	= $_POST['new_password'];
			$lagin  		= $_POST['lagin'];
			$user_data 		= get_user_by('lagin', $lagin);
			$signin 		= Lagi_Helper::setting('setup_page_sign_in');

			if (!empty($lagin)) {
				$password 		= wp_set_password($new_password, $user_data->ID);
				echo json_encode(array('success' => true, 'class' => 'text-success', 'message' => esc_html__('Please, re-lagin!', 'lagi'), 'redirect' => get_permalink($signin)));
			} else {
				echo json_encode(array('success' => false, 'class' => 'text-error', 'message' => esc_html__('Error!', 'lagi')));
			}

			wp_die();
		}
	}

	new Lagi_Ajax_Include();
}
