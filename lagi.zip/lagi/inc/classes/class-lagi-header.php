<?php
defined('ABSPATH') || exit;

if (!class_exists('Lagi_Header')) {

    class Lagi_Header
    {

        protected static $instance = null;

        public static function instance()
        {
            if (null === self::$instance) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        public function initialize()
        {
            add_action('init', array($this, 'register_header'));
            add_post_type_support('lagi_header', 'elementor');
        }

        /**
         * Register Header Post Type
         */
        function register_header()
        {
            $labels = array(
                'name' => __('Header', 'lagi'),
                'singular_name' => __('Header', 'lagi'),
                'add_new' => __('Add New', 'lagi'),
                'add_new_item' => __('Add New', 'lagi'),
                'edit_item' => __('Edit Header', 'lagi'),
                'new_item' => __('Add New Header', 'lagi'),
                'view_item' => __('View Header', 'lagi'),
                'search_items' => __('Search Header', 'lagi'),
                'not_found' => __('No items found', 'lagi'),
                'not_found_in_trash' => __('No items found in trash', 'lagi'),
            );

            $args = array(
                'menu_icon' => 'dashicons-buddicons-topics',
                'label' => esc_html__('Header', 'lagi'),
                'description' => esc_html__('Header', 'lagi'),
                'labels' => $labels,
                'supports' => array(
                    'title',
                    'editor',
                    'revisions',
                ),
                'hierarchical' => false,
                'public' => true,
                'menu_position' => 15,
                'show_in_admin_bar' => true,
                'show_in_nav_menus' => true,
                'can_export' => true,
                'has_archive' => false,
                'exclude_from_search' => true,
                'publicly_queryable' => false,
                'rewrite' => false,
                'capability_type' => 'page',
                'publicly_queryable' => true, // Enable TRUE for Elementor Editing
            );
            register_post_type('lagi_header', $args);
        }
    }

    Lagi_Header::instance()->initialize();
}
