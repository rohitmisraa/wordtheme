(function ($) {
    "use strict";

    var LagiBlogZoomHandler = function ($scope, $) {
        var $element = $scope.find(".lagi-blog-zoom");
        var $postItems = $element.find('.lagi-post-item');

        $postItems.first().addClass("active");
        $postItems.click(function() {
            var $this = $(this);
            if ($this.hasClass("active")) {
                $this.removeClass("active");
            } else {
                $postItems.removeClass("active");
                $this.addClass("active");
            }
        });
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/lagi-blog-zoom.default",
            LagiBlogZoomHandler
        );
    });
})(jQuery);
