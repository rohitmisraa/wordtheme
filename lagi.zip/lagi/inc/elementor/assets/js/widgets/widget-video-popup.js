(function ($) {
	"use strict";
	var LagiPopupVideoHandler = function ($scope, $) {
		var $element_slider = $scope.find(".lagi-slider-widget");
		$element_slider.LagiSwiper();

		var $element = $scope.find(".play-icon a");
		$element.each(function () {
			var span = $(this).find("span");
			var width = span.outerWidth() + 13;
			span.css("width", "0");
			$(this).hover(
				function () {
					span.css("width", width + "px");
					span.css("padding", "0 8px 0 5px");
				},
				function () {
					span.css("width", "0");
					span.css("padding", "0");
				}
			);
		});

		$(".lagi-video-carousel .play-icon a").on("click", function (e) {
			e.preventDefault();
			var href = $(this).attr("href");
			$(this)
				.closest(".lagi-video-carousel")
				.find(".lagi-popup-carousel-video iframe")
				.attr("src", href);
			$(this)
				.closest(".lagi-video-carousel")
				.find(".lagi-popup-carousel-video")
				.toggleClass("is-active");
		});

		$(".popup-close, .popup-bg").on("click", function (e) {
			e.preventDefault();
			$(this).closest(".lagi-popup-carousel-video").removeClass("is-active");
			$(this)
				.closest(".lagi-popup-carousel-video")
				.find("iframe")
				.attr("src", "");
		});
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-video-carousel.default",
			LagiPopupVideoHandler
		);
	});
})(jQuery);
