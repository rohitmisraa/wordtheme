(function ($) {
	"use strict";

	var SwiperHandler = function ($scope, $) {
		var $element = $scope.find(".lagi-slider-widget");

		$element.LagiSwiper();
	};

	var SwiperLinkedHandler = function ($scope, $) {
		var $element = $scope.find(".lagi-slider-widget");

		if ($scope.hasClass("lagi-swiper-linked-yes")) {
            var thumbsSlider = new Swiper(".lagi-thumbs-swiper", {
                loop: true,
                spaceBetween: 10,
                slidesPerView: 4,
                freeMode: true,
                watchSlidesProgress: true,
            });
			var mainSlider = $element.filter(".lagi-main-swiper").LagiSwiper({
				thumbs: {
					swiper: thumbsSlider,
				},
			});
		} else {
			$element.LagiSwiper();
		}
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-image-carousel.default",
			SwiperHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-modern-carousel.default",
			SwiperHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-modern-slider.default",
			SwiperHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-team-member-carousel.default",
			SwiperHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-product-carousel.default",
			SwiperHandler
		);

		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-testimonial.default",
			SwiperLinkedHandler
		);
	});
})(jQuery);
