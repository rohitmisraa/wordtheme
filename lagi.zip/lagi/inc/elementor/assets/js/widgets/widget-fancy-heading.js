(function ($) {
	"use strict";
	var LagiFancyHeadingHandler = function ($scope) {
		var $element = $scope.find(".lagi-fancy-heading");

		var options_default = {
			animationDelay: 4000,
			barAnimationDelay: 3000,
			typingSpeed: 200,
			typingDelay: 2000,
			typingLoop: false,
			typingCursor: false,
		};

		$element.each(function () {
			var $this = $(this);
			var options = $this.data("settings-options");
			var animationDelay = options.animationDelay;
			options = $.extend({}, options_default, options);
			options.barAnimationDelay = options.animationDelay;

			if (options.animationDelay < 3000) {
				options.barWaiting = options.animationDelay * (10 / 100);
			}
			if (options.animationDelay >= 3000) {
				options.barWaiting = options.animationDelay - 3000;
			}

			var duration = animationDelay;

			if ($this.hasClass("loading-bar")) {
				duration = options.barAnimationDelay;
				setTimeout(function () {
					$this.find(".lagi-fancy-heading-animated").addClass("is-loading");
				}, options.barWaiting);
			}

			if ($this.hasClass("lagi-fancy-heading-typing")) {
				var txt = $this.data("text");
				$this.find(".lagi-fancy-heading-animated").typed({
					strings: txt,
					typeSpeed: options.typingSpeed,
					backSpeed: 0,
					startDelay: 300,
					backDelay: options.typingDelay,
					showCursor: options.typingCursor,
					loop: options.typingLoop,
				});
			} else {
				setTimeout(function () {
					hideWord($this.find(".lagi-fancy-heading-show").eq(0), options);
				}, duration);
			}
		});

		function hideWord($word, options) {
			var nextWord = takeNext($word);
			if (
				$word
					.parents(".lagi-fancy-heading")
					.hasClass("lagi-fancy-heading-loading")
			) {
				$word.parent(".lagi-fancy-heading-animated").removeClass("is-loading");
				switchWord($word, nextWord);
				setTimeout(function () {
					hideWord(nextWord, options);
				}, options.barAnimationDelay);
				setTimeout(function () {
					$word.parent(".lagi-fancy-heading-animated").addClass("is-loading");
				}, options.barWaiting);
			} else {
				switchWord($word, nextWord);
				setTimeout(function () {
					hideWord(nextWord, options);
				}, options.animationDelay);
			}
		}

		function takeNext($word) {
			return !$word.is(":last-child")
				? $word.next()
				: $word.parent().children().eq(0);
		}

		function switchWord($oldWord, $newWord) {
			$oldWord
				.removeClass("lagi-fancy-heading-show")
				.addClass("lagi-fancy-heading-hidden");
			$newWord
				.removeClass("lagi-fancy-heading-hidden")
				.addClass("lagi-fancy-heading-show");
		}
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-fancy-heading.default",
			LagiFancyHeadingHandler
		);
	});
})(jQuery);
