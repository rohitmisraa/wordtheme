(function ($) {
	"use strict";

	var LagiPopupVideoHandler = function ($scope, $) {
		$(".video-link").on("click", function (e) {
			e.preventDefault();

			$(this).parent().find(".popup-bg").fadeIn();
			$(this).parent().find(".popup-content").fadeIn();
			$("body").addClass("open-popup");
		});

		$(".lagi-popup-video .popup-bg").on("click", function (e) {
			e.preventDefault();
			$("iframe").each(function (index) {
				$(this).attr("src", $(this).attr("src"));
				return false;
			});
			$(this).fadeOut();
			$(this).parent().find(".popup-content").fadeOut();
			$("body").removeClass("open-popup");
		});

		$(".video-poster .play-icon .inner").each(function () {
			var span = $(this).find("span");
			var width = span.outerWidth() + 17;
			span.css("width", "0");
			$(this).hover(
				function () {
					span.css("width", width + "px");
					span.css("padding", "0 12px 0 5px");
				},
				function () {
					span.css("width", "0");
					span.css("padding", "0");
				}
			);
		});
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-popup-video.default",
			LagiPopupVideoHandler
		);
	});
})(jQuery);
