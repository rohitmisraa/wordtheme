(function ($) {
	"use strict";

	var LagiPricingTableHandler = function ($scope, $) {};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-pricing-table.default",
			LagiPricingTableHandler
		);
	});
})(jQuery);
