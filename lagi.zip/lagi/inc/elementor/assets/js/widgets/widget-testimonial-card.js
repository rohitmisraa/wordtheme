(function ($) {
	"use strict";

	var LagiTestimonialCardHandler = function ($scope, $) {
		var swiper = new Swiper(".swiper-card", {
			effect: "cards",
			grabCursor: true,
			navigation: {
				nextEl: ".swiper-button-next",
				prevEl: ".swiper-button-prev",
			},
		});
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-testimonial-card.default",
			LagiTestimonialCardHandler
		);
	});
})(jQuery);
