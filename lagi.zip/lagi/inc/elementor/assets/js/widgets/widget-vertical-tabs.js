(function ($) {
    "use strict";

    const lagiVerticalTabsHandler = function ($scope, $) {
        const $element = $scope.find(".lagi-vertical-tabs");
        const content =  $element.find('.content-vertical-tabs');
        const autoPlay = content.data('autoplay');
        const time = content.data('time');
        const youtubeIframe = $element.find('iframe');
        let currentTab = 0;

        function reloadYouTubeVideo() {
            const src = youtubeIframe.attr('src');
            youtubeIframe.attr('src', src);
        }

        function activeTab(obj) {
            $element.find("ul li").removeClass("active");
            $element.find(obj).addClass("active");
            const id = $element.find(obj).find("a").attr("href");
            $element.find(".vertical-tabs-item").hide();
            $element.find(id).show();

            reloadYouTubeVideo();
        }

        function autoPlayTab() {
            const tabs = $element.find(".nav-vertical-tabs li");
            if (currentTab >= tabs.length) {
                currentTab = 0;
            }
            activeTab(tabs[currentTab]);
            currentTab++;
            setTimeout(autoPlayTab, time);
        }

        $element.find(".nav-vertical-tabs li").click(function (e) {
            e.preventDefault()
            activeTab(this);
            return false;
        });

        if (autoPlay == 'yes') {
            setTimeout(autoPlayTab, time);
        } else {
            activeTab($element.find("li:first-child"));
        }
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/lagi-vertical-tabs.default",
            lagiVerticalTabsHandler
        );
    });
})(jQuery);
