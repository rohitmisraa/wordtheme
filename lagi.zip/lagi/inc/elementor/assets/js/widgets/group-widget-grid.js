(function ($) {
	"use strict";

	var LagiGridHandler = function ($scope, $) {
		var $element = $scope.find(".lagi-grid-wrapper");

		$element.LagiGridLayout();
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-image-gallery.default",
			LagiGridHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-testimonial-grid.default",
			LagiGridHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-product-categories.default",
			LagiGridHandler
		);
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-client-logo.default",
			LagiGridHandler
		);
	});
})(jQuery);
