(function ($) {
	"use strict";
	var LagiImageLeftCarouselHandler = function ($scope, $) {
		var $element_slider = $scope.find(".lagi-slider-widget");
		$element_slider.LagiSwiper();
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-image-left-carousel.default",
			LagiImageLeftCarouselHandler
		);
	});
})(jQuery);
