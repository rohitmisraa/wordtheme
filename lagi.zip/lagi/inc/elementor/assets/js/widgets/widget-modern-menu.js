(function ($) {
	"use strict";

	var LagiModernMenuHandler = function ($scope, $) {
        $scope.find(
			"ul.elementor-nav-menu>li.menu-item-has-children>a"
		).append('<span class="sub-arrow"><i class="far fa-angle-down"></i></span>');
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-modern-menu.default",
			LagiModernMenuHandler
		);
	});
})(jQuery);
