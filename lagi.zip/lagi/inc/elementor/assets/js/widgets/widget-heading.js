(function ($) {
    "use strict";

    var LagiHeading1Handler = function ($scope, $) {
        const title = $scope.find(".elementor-heading-title");
        const imageUrl = title.data('image');
        if(imageUrl){
            const mark = title.find('mark');
            const spanElement = $('<span class="image"><image src="' + imageUrl + '"  alt=""/></span>');
            mark.append(spanElement);
        }
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/lagi-heading.default",
            LagiHeading1Handler
        );
    });
})(jQuery);
