(function ($) {
    "use strict";
    var LagiImageCoverflowCarouselHandler = function ($scope, $) {
        var item = $('.lagi-image-coverflow-slider').find('.swiper-slide .item');
        var titles = [];
        item.each(function(index) {
            var title = $(this).data('title');
            titles.push(title);
        });
        var swiper = new Swiper('.lagi-image-coverflow-slider', {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 100,
                modifier: 2.5,
                slideShadows: true,
            },
            slidesPerView: 'auto',
            loop: true,
            spaceBetween: 30,
            pagination: {
                el: '.swiper-pagination-text',
                clickable: true,
                bulletClass: 'swiper-pagination-bullet',
                bulletActiveClass: 'swiper-pagination-bullet-active',
                renderBullet: function (index, className) {
                    return '<span class="' + className + '">' + titles[index] + '</span>';
                }
            }
        });
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/lagi-image-coverflow-carousel.default",
            LagiImageCoverflowCarouselHandler
        );
    });
})(jQuery);
