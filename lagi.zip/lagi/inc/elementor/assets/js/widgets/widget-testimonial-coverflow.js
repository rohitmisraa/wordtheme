(function ($) {
	"use strict";

	var LagiTestimonialCoverflowHandler = function ($scope, $) {
		var swiper = new Swiper(".lagi-testimonial-coverflow .swiper-coverflow", {
			effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            coverflowEffect: {
                rotate: 5,
                stretch: 0,
                depth: 100,
                modifier: 3.9,
                slideShadows: true,
            },
            keyboard: {
                enabled: true
            },
            mousewheel: {
                thresholdDelta: 70
            },
            spaceBetween: 30,
            breakpoints: {
                640: {
                    slidesPerView: 2
                },
                1024: {
                    slidesPerView: 3
                }
            },
			navigation: {
				nextEl: ".swiper-button-next",
				prevEl: ".swiper-button-prev",
			},
			pagination: {
				el: ".swiper-pagination",
				clickable: true, // Enable navigation by clicking the dots
			},
			loop: true,
		});
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-testimonial-coverflow.default",
			LagiTestimonialCoverflowHandler
		);
	});
})(jQuery);
