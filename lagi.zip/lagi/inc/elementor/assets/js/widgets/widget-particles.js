(function ($) {
	"use strict";

	var LagiParticles = function ($scope, $) {
		var element = $scope.find("#uxper-particles");

		element.each(function () {
			var style = element.attr("data-style"),
				number = element.attr("data-number"),
				dot_color = element.attr("data-dot-color"),
				dot_color_1 = element.attr("data-dot-color-1"),
				dot_color_2 = element.attr("data-dot-color-2"),
				dot_color_3 = element.attr("data-dot-color-3"),
				line_color = "#ffffff",
				opacity = element.attr("data-opacity"),
				speed = element.attr("data-speed"),
				color = "#ffffff",
				line_linked = true;

			if (style == "default") {
				color = dot_color;
				line_color = element.attr("data-line-color");
			} else if (style == "nasa") {
				color = [dot_color_1, dot_color_2, dot_color_3];
				line_linked = false;
			}

			particlesJS(
				element[0].id,

				{
					particles: {
						number: {
							value: number,
							density: {
								enable: true,
								value_area: 800,
							},
						},
						color: {
							value: color,
						},
						shape: {
							type: "circle",
							stroke: {
								width: 0,
								color: "#000000",
							},
							polygon: {
								nb_sides: 5,
							},
							image: {
								src: "img/github.svg",
								width: 100,
								height: 100,
							},
						},
						opacity: {
							value: opacity,
							random: false,
							anim: {
								enable: false,
								speed: 1,
								opacity_min: 0.1,
								sync: false,
							},
						},
						size: {
							value: 5,
							random: true,
							anim: {
								enable: false,
								speed: 40,
								size_min: 0.1,
								sync: false,
							},
						},
						line_linked: {
							enable: line_linked,
							distance: 150,
							color: line_color,
							opacity: opacity,
							width: 1,
						},
						move: {
							enable: true,
							speed: speed,
							direction: "none",
							random: false,
							straight: false,
							out_mode: "out",
							attract: {
								enable: false,
								rotateX: 600,
								rotateY: 1200,
							},
						},
					},
					interactivity: {
						detect_on: "canvas",
						events: {
							onhover: {
								enable: false,
								mode: "repulse",
							},
							onclick: {
								enable: false,
								mode: "push",
							},
							resize: true,
						},
						modes: {
							grab: {
								distance: 400,
								line_linked: {
									opacity: 1,
								},
							},
							bubble: {
								distance: 400,
								size: 40,
								duration: 2,
								opacity: 8,
								speed: 3,
							},
							repulse: {
								distance: 200,
							},
							push: {
								particles_nb: 4,
							},
							remove: {
								particles_nb: 2,
							},
						},
					},
					retina_detect: true,
					config_demo: {
						hide_card: false,
						background_color: "#b61924",
						background_image: "",
						background_position: "50% 50%",
						background_repeat: "no-repeat",
						background_size: "cover",
					},
				}
			);
		});
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-particles.default",
			LagiParticles
		);
	});
})(jQuery);
