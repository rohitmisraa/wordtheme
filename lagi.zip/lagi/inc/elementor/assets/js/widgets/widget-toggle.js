(function ($) {
    "use strict";
    var LagiToggleHandler = function ($scope, $) {
        function caculate_pricing_li_height($param) {
            var height = [];
            var sum_li = 0;

            $(".lagi-pricing-features").each(function () {
                var li = $(this).attr("data-count");
                if (li > sum_li) {
                    sum_li = li;
                }
            });

            for (let i = 0; i < sum_li; i++) {
                $param.find(".lagi-pricing-features").each(function () {
                    var item_height = $(this)
                        .find("li:nth-child(" + (i + 1) + ")")
                        .innerHeight();
                    if (height.hasOwnProperty(i)) {
                        if (item_height > height[i]) {
                            height[i] = item_height;
                        }
                    } else {
                        height.push(item_height);
                    }
                });
            }

            for (let j = 0; j <= height.length; j++) {
                $param
                    .find(".lagi-pricing-features li:nth-child( " + (j + 1) + " )")
                    .css("height", height[j] + "px");
            }
        }

        if ($(".lagi-pricing-plan").hasClass("sercondary")) {
            caculate_pricing_li_height(
                $(".pricing-plan-item.pricing-plan-sercondary")
            );
        } else {
            caculate_pricing_li_height(
                $(".pricing-plan-item.pricing-plan-primary")
            );
        }

        $(".lagi-pricing-plan .switch").on("click", function (e) {
            e.preventDefault();

            var _this = $(this),
                item = $(this)
                    .parents(".lagi-pricing-plan")
                    .find(".pricing-plan-item");

            $(".lagi-pricing-plan .switch-label .switch").removeClass("active");
            _this.toggleClass("active");

            item.each(function () {
                if ($(this).hasClass("active")) {
                    $(this).removeClass("active");
                } else {
                    $(this).addClass("active");
                }
            });

            if (_this.closest(".lagi-pricing-plan").hasClass("sercondary")) {
                caculate_pricing_li_height(
                    $(".pricing-plan-item.pricing-plan-primary")
                );
            } else {
                caculate_pricing_li_height(
                    $(".pricing-plan-item.pricing-plan-sercondary")
                );
            }
        });
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/lagi-content-toggle.default",
            LagiToggleHandler
        );
    });
})(jQuery);
