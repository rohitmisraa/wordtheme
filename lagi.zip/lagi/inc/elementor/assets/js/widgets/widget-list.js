(function ($) {
	"use strict";

	var LagiListHandler = function ($scope, $) {
		var $element = $scope.find(".lagi-list");
		var $heading = $element.find(".heading");
        var $list_inner = $element.find(".list-inner");

		var id_control = $element.data("id");

		if (id_control) {
			$('.lagi-list[data-id="' + id_control + '"] .item:nth-child(1)').addClass(
				"active"
			);

			$element.on("click", ".item", function (e) {
				e = e || window.event;
				e.preventDefault();
				e.stopPropagation();

				var index = $(this).index();
				const imageCarousel = $("#" + id_control + " .swiper-container");
				var swiperInstance = imageCarousel[0]["swiper"];
				swiperInstance.slideTo(index);
				$(this).addClass("active");
				$(".lagi-list .item").not(this).removeClass("active");
			});
		}

        if (window.matchMedia("(max-width: 576px)").matches) {
            $heading.click(function () {
                $list_inner.slideToggle();
                $(this).find("i").toggleClass("far fa-chevron-up far fa-chevron-down");
            });
        }
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-list.default",
			LagiListHandler
		);
	});
})(jQuery);
