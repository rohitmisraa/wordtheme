(function ($) {
	"use strict";

	const lagiModernTabsHandler = function ($scope, $) {
		const $element = $scope.find(".lagi-modern-tabs");

		function activeTab(obj) {
			$element.find("ul li").removeClass("active");
			$element.find(obj).addClass("active");
			const id = $element.find(obj).find("a").attr("href");
			$element.find(".modern-tabs-item").hide();
			$element.find(id).show();
			$element.find(id).find('.lagi-grid-wrapper').LagiGridLayout();
		}
		$element.find(".nav-modern-tabs li").click(function (e) {
			e.preventDefault()
			activeTab(this);
			return false;
		});

		activeTab($element.find("li:first-child"));
	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/lagi-modern-tabs.default",
			lagiModernTabsHandler
		);
	});
})(jQuery);
