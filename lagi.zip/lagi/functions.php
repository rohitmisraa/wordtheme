<?php

/**
 * Lagi functions and definitions
 *
 * @package lagi
 */

require_once get_template_directory() . '/inc/init.php';
