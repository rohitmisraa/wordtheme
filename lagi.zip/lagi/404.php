<?php

/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 */
get_header();

$type     = Lagi_Helper::setting('page404_type');
$button   = Lagi_Helper::setting('page404_button');
$image    = Lagi_Helper::setting('page404_image');
$bg_image = Lagi_Helper::setting('page404_bg_image');
$title    = Lagi_Helper::setting('page404_title');
$text     = Lagi_Helper::setting('page404_text');

if ($type !== '') {
    if (defined('ELEMENTOR_VERSION')) {
        echo \Elementor\Plugin::$instance->frontend->get_builder_content($type);
    } else {
        $page404 = get_post($type);
        if (!empty($page404->post_content)) {
            echo wp_kses_post($page404->post_content);
        }
    }
} else { ?>
    <div class="page-404-content">
        <div class="container">

            <?php if ($image !== '') : ?>
                <div class="error-image" style="background-image: url('<?php if ($bg_image !== '') {
                                                                            echo $bg_image;
                                                                        } ?>')">
                    <img src="<?php echo esc_url($image); ?>" alt="<?php esc_attr_e('Not Found Image', 'lagi'); ?>" />
                </div>
            <?php endif; ?>

            <?php if ($title !== '') : ?>
                <h2 class="error-404-title">
                    <?php echo wp_kses($title, 'lagi'); ?>
                </h2>
            <?php endif; ?>

            <?php if ($text !== '') : ?>
                <div class="error-404-text">
                    <?php echo wp_kses($text, Lagi_Helper::lagi_kses_allowed_html()); ?>
                </div>
            <?php endif; ?>

            <?php if ($button !== '') : ?>
                <a href="<?php echo esc_url(home_url()); ?>" class="lagi-btn btn-outline btn-icon-right">
                    <?php echo wp_kses($button, 'lagi'); ?>
                    <i class="fas fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>
<?php }

get_footer();
